-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: energy_tracker
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `daily_energy_summaries`
--

DROP TABLE IF EXISTS `daily_energy_summaries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `daily_energy_summaries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `machine_id` bigint unsigned NOT NULL,
  `date` date NOT NULL,
  `kwh_usage` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `daily_energy_summaries_machine_id_date_unique` (`machine_id`,`date`),
  CONSTRAINT `daily_energy_summaries_machine_id_foreign` FOREIGN KEY (`machine_id`) REFERENCES `machines` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_energy_summaries`
--

LOCK TABLES `daily_energy_summaries` WRITE;
/*!40000 ALTER TABLE `daily_energy_summaries` DISABLE KEYS */;
INSERT INTO `daily_energy_summaries` VALUES (69,3,'2026-04-25',12.57,'2026-04-25 11:56:03','2026-04-25 11:56:03'),(70,3,'2026-04-27',101.64,'2026-04-27 16:10:46','2026-04-27 23:52:05'),(71,3,'2026-04-28',54.59,'2026-04-28 00:12:05','2026-04-28 09:12:05');
/*!40000 ALTER TABLE `daily_energy_summaries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `devices`
--

DROP TABLE IF EXISTS `devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `devices` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('power_meter','temperature_sensor','humidity_sensor') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `machine_id` bigint unsigned DEFAULT NULL,
  `slave_id` int NOT NULL,
  `communication_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'RS485',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `devices_machine_id_foreign` (`machine_id`),
  CONSTRAINT `devices_machine_id_foreign` FOREIGN KEY (`machine_id`) REFERENCES `machines` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devices`
--

LOCK TABLES `devices` WRITE;
/*!40000 ALTER TABLE `devices` DISABLE KEYS */;
INSERT INTO `devices` VALUES (1,'Meter PM-01','power_meter',1,1,'RS485',1,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(2,'Meter PM-02','power_meter',2,2,'RS485',1,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(3,'Meter PM-03','power_meter',3,3,'RS485',1,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(4,'Meter PM-04','power_meter',4,4,'RS485',1,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(5,'Meter PM-05','power_meter',5,5,'RS485',1,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(6,'Meter PM-06','power_meter',6,6,'RS485',1,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(7,'Meter PM-07','power_meter',7,7,'RS485',1,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(8,'Meter PM-08','power_meter',8,8,'RS485',1,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(9,'Meter PM-09','power_meter',9,9,'RS485',1,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(10,'Meter PM-10','power_meter',10,10,'RS485',1,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(11,'Meter PM-11','power_meter',11,11,'RS485',1,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(12,'Meter PM-12','power_meter',12,12,'RS485',1,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(13,'Meter PM-13','power_meter',13,13,'RS485',1,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(14,'Meter PM-14','power_meter',14,14,'RS485',1,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(15,'Meter PM-15','power_meter',15,15,'RS485',1,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(16,'Meter PM-16','power_meter',16,16,'RS485',1,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(17,'Meter PM-17','power_meter',17,17,'RS485',1,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(18,'Meter PM-18','power_meter',18,18,'RS485',1,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(19,'Meter PM-19','power_meter',19,19,'RS485',1,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(20,'Meter PM-20','power_meter',20,20,'RS485',1,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(21,'Meter PM-21','power_meter',21,21,'RS485',1,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(22,'Meter PM-22','power_meter',22,22,'RS485',1,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(23,'Factory Floor DHT Sensor','temperature_sensor',NULL,100,'RS485',1,'2026-04-02 00:42:19','2026-04-02 00:42:19');
/*!40000 ALTER TABLE `devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `environmental_readings`
--

DROP TABLE IF EXISTS `environmental_readings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `environmental_readings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `device_id` bigint unsigned NOT NULL,
  `temperature` double DEFAULT NULL,
  `humidity` double DEFAULT NULL,
  `recorded_at` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  KEY `environmental_readings_device_id_recorded_at_index` (`device_id`,`recorded_at`),
  CONSTRAINT `environmental_readings_device_id_foreign` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=336 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `environmental_readings`
--

LOCK TABLES `environmental_readings` WRITE;
/*!40000 ALTER TABLE `environmental_readings` DISABLE KEYS */;
/*!40000 ALTER TABLE `environmental_readings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `locations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locations`
--

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT INTO `locations` VALUES (1,'Peroni Karya Sentra','Main Manufacturing Plant','2026-04-02 00:42:19','2026-04-02 00:42:19');
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `machines`
--

DROP TABLE IF EXISTS `machines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `machines` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `location_id` bigint unsigned NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `kwh_baseline` double NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `machines_code_unique` (`code`),
  KEY `machines_location_id_foreign` (`location_id`),
  CONSTRAINT `machines_location_id_foreign` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `machines`
--

LOCK TABLES `machines` WRITE;
/*!40000 ALTER TABLE `machines` DISABLE KEYS */;
INSERT INTO `machines` VALUES (1,'BAHAN BAKU','PM-01',1,1,0,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(2,'BAHAN BAKU','PM-02',1,1,0,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(3,'COR PASIR','PM-03',1,1,0,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(4,'COR PASIR','PM-04',1,1,0,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(5,'COR PASIR','PM-05',1,1,0,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(6,'COR LOST WAX','PM-06',1,1,0,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(7,'NETTO FLANGE','PM-07',1,1,0,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(8,'NETTO FITTING','PM-08',1,1,0,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(9,'BUBUT FLANGE','PM-09',1,1,0,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(10,'BUBUT FITTING','PM-10',1,1,0,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(11,'BUBUT BESI','PM-11',1,1,0,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(12,'BOR FLANGE','PM-12',1,1,0,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(13,'FINISH FLANGE','PM-13',1,1,0,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(14,'GUDANG JADI FLANGE','PM-14',1,1,0,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(15,'GUDANG JADI FITTING','PM-15',1,1,0,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(16,'SPECTRO','PM-16',1,1,0,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(17,'HEAT TREATMENT','PM-17',1,1,0,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(18,'KIMIA FITTING','PM-18',1,1,0,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(19,'MAINTENANCE','PM-19',1,1,0,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(20,'TPS NON B3','PM-20',1,1,0,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(21,'MILLING','PM-21',1,1,0,'2026-04-02 00:42:19','2026-04-02 00:42:19'),(22,'CETAK LOST WAX','PM-22',1,1,0,'2026-04-02 00:42:19','2026-04-02 00:42:19');
/*!40000 ALTER TABLE `machines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meter_resets`
--

DROP TABLE IF EXISTS `meter_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `meter_resets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `machine_id` bigint unsigned NOT NULL,
  `kwh_at_reset` double NOT NULL,
  `notes` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `performed_by` bigint unsigned DEFAULT NULL,
  `reset_at` timestamp NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `meter_resets_performed_by_foreign` (`performed_by`),
  KEY `meter_resets_machine_id_reset_at_index` (`machine_id`,`reset_at`),
  CONSTRAINT `meter_resets_machine_id_foreign` FOREIGN KEY (`machine_id`) REFERENCES `machines` (`id`) ON DELETE CASCADE,
  CONSTRAINT `meter_resets_performed_by_foreign` FOREIGN KEY (`performed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meter_resets`
--

LOCK TABLES `meter_resets` WRITE;
/*!40000 ALTER TABLE `meter_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `meter_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'0_create_locations_table',1),(5,'1_create_machines_table',1),(6,'2_create_devices_table',1),(7,'3_create_power_readings_table',1),(8,'4_create_environmental_readings_table',1),(9,'5_create_daily_energy_summaries_table',1),(10,'6_add_kwh_baseline_to_machines',2),(11,'7_create_meter_resets_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `power_readings`
--

DROP TABLE IF EXISTS `power_readings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `power_readings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `device_id` bigint unsigned NOT NULL,
  `kwh_total` double NOT NULL,
  `power_kw` double DEFAULT NULL,
  `voltage` double DEFAULT NULL,
  `current` double DEFAULT NULL,
  `power_factor` double DEFAULT NULL,
  `recorded_at` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  KEY `power_readings_device_id_recorded_at_index` (`device_id`,`recorded_at`),
  CONSTRAINT `power_readings_device_id_foreign` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8676 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `power_readings`
--

LOCK TABLES `power_readings` WRITE;
/*!40000 ALTER TABLE `power_readings` DISABLE KEYS */;
INSERT INTO `power_readings` VALUES (7375,3,4918,0,0,0,0,'2026-04-24 14:06:21'),(7376,3,4918,0,0,0,0,'2026-04-24 14:16:21'),(7377,3,4918,0,0,0,0,'2026-04-24 14:26:21'),(7378,3,4918,0,0,0,0,'2026-04-24 14:36:21'),(7379,3,4918,0,0,0,0,'2026-04-24 14:46:21'),(7380,3,4918,0,0,0,0,'2026-04-24 14:56:21'),(7381,3,4918,0,0,0,0,'2026-04-24 15:06:21'),(7382,3,4918,0,0,0,0,'2026-04-24 15:16:21'),(7383,3,4918,0,0,0,0,'2026-04-24 15:26:21'),(7384,3,4918,0,0,0,0,'2026-04-24 15:36:21'),(7385,3,4918,0,0,0,0,'2026-04-24 15:46:21'),(7386,3,4918,0,0,0,0,'2026-04-24 15:56:21'),(7387,3,4918,0,0,0,0,'2026-04-24 16:06:21'),(7388,3,4918,0,0,0,0,'2026-04-24 16:16:21'),(7389,3,4918,0,0,0,0,'2026-04-24 16:26:21'),(7390,3,4918,0,0,0,0,'2026-04-24 16:36:21'),(7391,3,4918,0,0,0,0,'2026-04-24 16:46:21'),(7392,3,4918,0,0,0,0,'2026-04-24 16:56:21'),(7393,3,4918,0,0,0,0,'2026-04-24 17:06:21'),(7394,3,4918,0,0,0,0,'2026-04-24 17:16:21'),(7395,3,4918,0,0,0,0,'2026-04-24 17:26:21'),(7396,3,4918,0,0,0,0,'2026-04-24 17:36:21'),(7397,3,4918,0,0,0,0,'2026-04-24 17:46:21'),(7398,3,4918,0,0,0,0,'2026-04-24 17:56:21'),(7399,3,4918,0,0,0,0,'2026-04-24 18:06:21'),(7400,3,4918,0,0,0,0,'2026-04-24 18:16:21'),(7401,3,4918,0,0,0,0,'2026-04-24 18:26:21'),(7402,3,4918,0,0,0,0,'2026-04-24 18:36:21'),(7403,3,4918,0,0,0,0,'2026-04-24 18:46:21'),(7404,3,4918,0,0,0,0,'2026-04-24 18:56:21'),(7405,3,4918,0,0,0,0,'2026-04-24 19:06:21'),(7406,3,4918,0,0,0,0,'2026-04-24 19:16:21'),(7407,3,4918,0,0,0,0,'2026-04-24 19:26:21'),(7408,3,4918,0,0,0,0,'2026-04-24 19:36:21'),(7409,3,4918,0,0,0,0,'2026-04-24 19:46:21'),(7410,3,4918,0,0,0,0,'2026-04-24 19:56:21'),(7411,3,4918,0,0,0,0,'2026-04-24 20:06:21'),(7412,3,4918,0,0,0,0,'2026-04-24 20:16:21'),(7413,3,4918,0,0,0,0,'2026-04-24 20:26:21'),(7414,3,4918,0,0,0,0,'2026-04-24 20:36:21'),(7415,3,4918,0,0,0,0,'2026-04-24 20:46:21'),(7416,3,4918,0,0,0,0,'2026-04-24 20:56:21'),(7417,3,4918,0,0,0,0,'2026-04-24 21:06:21'),(7418,3,4918,0,0,0,0,'2026-04-24 21:16:21'),(7419,3,4918,0,0,0,0,'2026-04-24 21:26:21'),(7420,3,4918,0,0,0,0,'2026-04-24 21:36:21'),(7421,3,4918,0,0,0,0,'2026-04-24 21:46:21'),(7422,3,4918,0,0,0,0,'2026-04-24 21:56:21'),(7423,3,4918,0,0,0,0,'2026-04-24 22:06:21'),(7424,3,4918,0,0,0,0,'2026-04-24 22:16:21'),(7425,3,4918,0,0,0,0,'2026-04-24 22:26:21'),(7426,3,4918,0,0,0,0,'2026-04-24 22:36:21'),(7427,3,4918,0,0,0,0,'2026-04-24 22:46:21'),(7428,3,4918,0,0,0,0,'2026-04-24 22:56:21'),(7429,3,4918,0,0,0,0,'2026-04-24 23:06:21'),(7430,3,4918,0,0,0,0,'2026-04-24 23:16:21'),(7431,3,4918,0,0,0,0,'2026-04-24 23:26:21'),(7432,3,4918,0,0,0,0,'2026-04-24 23:36:21'),(7433,3,4918,0,0,0,0,'2026-04-24 23:46:21'),(7434,3,4918,0,0,0,0,'2026-04-24 23:56:21'),(7504,3,3782.34,6.139,545.8,0.66,0.958,'2026-04-25 09:41:56'),(7505,3,3782.34,6.174,545.7,0.67,0.958,'2026-04-25 09:42:56'),(7506,3,3782.34,6.168,545.8,0.72,0.958,'2026-04-25 09:43:56'),(7507,3,3782.34,6.17,545.6,0.69,0.959,'2026-04-25 09:44:56'),(7508,3,3782.34,6.247,5,10.4,0.504,'2026-04-25 09:45:56'),(7509,3,3782.34,6.102,554,0.64,0.958,'2026-04-25 09:46:56'),(7510,3,3782.34,6.127,559.6,0.63,0.959,'2026-04-25 09:47:56'),(7511,3,3782.34,6.16,559.3,0.67,0.959,'2026-04-25 09:48:56'),(7512,3,3782.34,6.123,559,0.63,0.959,'2026-04-25 09:49:56'),(7513,3,3782.34,6.114,559.3,0.62,0.959,'2026-04-25 09:50:56'),(7514,3,3782.34,6.132,559.2,0.64,0.959,'2026-04-25 09:51:56'),(7515,3,3782.34,6.136,559.4,0.63,0.959,'2026-04-25 09:52:38'),(7516,3,3782.34,6.148,559.4,0.6,0.959,'2026-04-25 09:53:38'),(7517,3,3782.34,6.165,559.3,0.69,0.959,'2026-04-25 09:54:38'),(7518,3,3782.34,6.176,559.3,0.63,0.959,'2026-04-25 09:55:38'),(7519,3,3782.34,6.151,559.1,0.73,0.959,'2026-04-25 09:56:38'),(7520,3,3782.34,6.105,558.9,0.75,0.959,'2026-04-25 09:57:35'),(7521,3,3782.34,6.14,34.3,13.22,0.819,'2026-04-25 10:07:35'),(7522,3,3782.34,6.088,552.9,0.66,0.959,'2026-04-25 10:17:35'),(7523,3,3782.34,6.178,552.5,0.69,0.959,'2026-04-25 10:27:35'),(7524,3,3782.34,6.187,552.6,0.7,0.959,'2026-04-25 10:37:35'),(7525,3,3782.34,6.133,552.5,0.65,0.96,'2026-04-25 10:47:35'),(7526,3,3782.34,6.179,544.3,0.73,0.959,'2026-04-25 10:54:54'),(7527,3,3782.34,6.104,76.8,4.98,0.933,'2026-04-25 11:04:54'),(7528,3,3782.34,6.054,349.6,0.78,0.959,'2026-04-25 11:14:54'),(7529,3,3782.34,6.047,435.8,0.69,0.959,'2026-04-25 11:24:54'),(7530,3,3782.34,6.012,438.3,0.65,0.959,'2026-04-25 11:34:54'),(7531,3,3782.34,6.084,535.4,0.55,0.959,'2026-04-25 11:44:54'),(7532,3,3782.34,0,0,0,0,'2026-04-25 15:04:59'),(7533,3,3782.34,0,0,0,0,'2026-04-25 15:14:59'),(7534,3,3782.34,0,0,0,0,'2026-04-25 15:24:59'),(7535,3,3782.34,0,0,0,0,'2026-04-25 15:30:46'),(7536,3,3782.34,0,0,0,0,'2026-04-25 15:40:46'),(7537,3,3782.34,0,0,0,0,'2026-04-25 15:50:46'),(7538,3,3782.34,0,0,0,0,'2026-04-25 16:00:46'),(7539,3,3782.34,0,0,0,0,'2026-04-25 16:10:46'),(7540,3,3782.34,0,0,0,0,'2026-04-25 16:20:46'),(7541,3,3782.34,0,0,0,0,'2026-04-25 16:30:46'),(7542,3,3782.34,0,0,0,0,'2026-04-25 16:40:46'),(7543,3,3782.34,0,0,0,0,'2026-04-25 16:50:46'),(7544,3,3782.34,0,0,0,0,'2026-04-25 17:00:46'),(7545,3,3782.34,0,0,0,0,'2026-04-25 17:10:46'),(7546,3,3782.34,0,0,0,0,'2026-04-25 17:20:46'),(7547,3,3782.34,0,0,0,0,'2026-04-25 17:30:46'),(7548,3,3782.34,0,0,0,0,'2026-04-25 17:40:46'),(7549,3,3782.34,0,0,0,0,'2026-04-25 17:50:46'),(7550,3,3782.34,0,0,0,0,'2026-04-25 18:00:46'),(7551,3,3782.34,0,0,0,0,'2026-04-25 18:10:46'),(7552,3,3782.34,0,0,0,0,'2026-04-25 18:20:46'),(7553,3,3782.34,0,0,0,0,'2026-04-25 18:30:46'),(7554,3,3782.34,0,0,0,0,'2026-04-25 18:40:46'),(7555,3,3782.34,0,0,0,0,'2026-04-25 18:50:46'),(7556,3,3782.34,0,0,0,0,'2026-04-25 19:00:46'),(7557,3,3782.34,0,0,0,0,'2026-04-25 19:10:46'),(7558,3,3782.34,0,0,0,0,'2026-04-25 19:20:46'),(7559,3,3782.34,0,0,0,0,'2026-04-25 19:30:46'),(7560,3,3782.34,0,0,0,0,'2026-04-25 19:40:46'),(7561,3,3782.34,0,0,0,0,'2026-04-25 19:50:46'),(7562,3,3782.34,0,0,0,0,'2026-04-25 20:00:46'),(7563,3,3782.34,0,0,0,0,'2026-04-25 20:10:46'),(7564,3,3782.34,0,0,0,0,'2026-04-25 20:20:46'),(7565,3,3782.34,0,0,0,0,'2026-04-25 20:30:46'),(7566,3,3782.34,0,0,0,0,'2026-04-25 20:40:46'),(7567,3,3782.34,0,0,0,0,'2026-04-25 20:50:46'),(7568,3,3782.34,0,0,0,0,'2026-04-25 21:00:46'),(7569,3,3782.34,0,0,0,0,'2026-04-25 21:10:46'),(7570,3,3782.34,0,0,0,0,'2026-04-25 21:20:46'),(7571,3,3782.34,0,0,0,0,'2026-04-25 21:30:46'),(7572,3,3782.34,0,0,0,0,'2026-04-25 21:40:46'),(7573,3,3782.34,0,0,0,0,'2026-04-25 21:50:46'),(7574,3,3782.34,0,0,0,0,'2026-04-25 22:00:46'),(7575,3,3782.34,0,0,0,0,'2026-04-25 22:10:46'),(7576,3,3782.34,0,0,0,0,'2026-04-25 22:20:46'),(7577,3,3782.34,0,0,0,0,'2026-04-25 22:30:46'),(7578,3,3782.34,0,0,0,0,'2026-04-25 22:40:46'),(7579,3,3782.34,0,0,0,0,'2026-04-25 22:50:46'),(7580,3,3782.34,0,0,0,0,'2026-04-25 23:00:46'),(7581,3,3782.34,0,0,0,0,'2026-04-25 23:10:46'),(7582,3,3782.34,0,0,0,0,'2026-04-25 23:20:46'),(7583,3,3782.34,0,0,0,0,'2026-04-25 23:30:46'),(7584,3,3782.34,0,0,0,0,'2026-04-25 23:40:46'),(7585,3,3782.34,0,0,0,0,'2026-04-25 23:50:46'),(7586,3,3782.34,0,0,0,0,'2026-04-26 00:00:46'),(7587,3,3782.34,0,0,0,0,'2026-04-26 00:10:46'),(7588,3,3782.34,0,0,0,0,'2026-04-26 00:20:46'),(7589,3,3782.34,0,0,0,0,'2026-04-26 00:30:46'),(7590,3,3782.34,0,0,0,0,'2026-04-26 00:40:46'),(7591,3,3782.34,0,0,0,0,'2026-04-26 00:50:46'),(7592,3,3782.34,0,0,0,0,'2026-04-26 01:00:46'),(7593,3,3782.34,0,0,0,0,'2026-04-26 01:10:46'),(7594,3,3782.34,0,0,0,0,'2026-04-26 01:20:46'),(7595,3,3782.34,0,0,0,0,'2026-04-26 01:30:46'),(7596,3,3782.34,0,0,0,0,'2026-04-26 01:40:46'),(7597,3,3782.34,0,0,0,0,'2026-04-26 01:50:46'),(7598,3,3782.34,0,0,0,0,'2026-04-26 02:00:46'),(7599,3,3782.34,0,0,0,0,'2026-04-26 02:10:46'),(7600,3,3782.34,0,0,0,0,'2026-04-26 02:20:46'),(7601,3,3782.34,0,0,0,0,'2026-04-26 02:30:46'),(7602,3,3782.34,0,0,0,0,'2026-04-26 02:40:46'),(7603,3,3782.34,0,0,0,0,'2026-04-26 02:50:46'),(7604,3,3782.34,0,0,0,0,'2026-04-26 03:00:46'),(7605,3,3782.34,0,0,0,0,'2026-04-26 03:10:46'),(7606,3,3782.34,0,0,0,0,'2026-04-26 03:20:46'),(7607,3,3782.34,0,0,0,0,'2026-04-26 03:30:46'),(7608,3,3782.34,0,0,0,0,'2026-04-26 03:40:46'),(7609,3,3782.34,0,0,0,0,'2026-04-26 03:50:46'),(7610,3,3782.34,0,0,0,0,'2026-04-26 04:00:46'),(7611,3,3782.34,0,0,0,0,'2026-04-26 04:10:46'),(7612,3,3782.34,0,0,0,0,'2026-04-26 04:20:46'),(7613,3,3782.34,0,0,0,0,'2026-04-26 04:30:46'),(7614,3,3782.34,0,0,0,0,'2026-04-26 04:40:46'),(7615,3,3782.34,0,0,0,0,'2026-04-26 04:50:46'),(7616,3,3782.34,0,0,0,0,'2026-04-26 05:00:46'),(7617,3,3782.34,0,0,0,0,'2026-04-26 05:10:46'),(7618,3,3782.34,0,0,0,0,'2026-04-26 05:20:46'),(7619,3,3782.34,0,0,0,0,'2026-04-26 05:30:46'),(7620,3,3782.34,0,0,0,0,'2026-04-26 05:40:46'),(7621,3,3782.34,0,0,0,0,'2026-04-26 05:50:46'),(7622,3,3782.34,0,0,0,0,'2026-04-26 06:00:46'),(7623,3,3782.34,0,0,0,0,'2026-04-26 06:10:46'),(7624,3,3782.34,0,0,0,0,'2026-04-26 06:20:46'),(7625,3,3782.34,0,0,0,0,'2026-04-26 06:30:46'),(7626,3,3782.34,0,0,0,0,'2026-04-26 06:40:46'),(7627,3,3782.34,0,0,0,0,'2026-04-26 06:50:46'),(7628,3,3782.34,0,0,0,0,'2026-04-26 07:00:46'),(7629,3,3782.34,0,0,0,0,'2026-04-26 07:10:46'),(7630,3,3782.34,0,0,0,0,'2026-04-26 07:20:46'),(7631,3,3782.34,0,0,0,0,'2026-04-26 07:30:46'),(7632,3,3782.34,0,0,0,0,'2026-04-26 07:40:46'),(7633,3,3782.34,0,0,0,0,'2026-04-26 07:50:46'),(7634,3,3782.34,0,0,0,0,'2026-04-26 08:00:46'),(7635,3,3782.34,0,0,0,0,'2026-04-26 08:10:46'),(7636,3,3782.34,0,0,0,0,'2026-04-26 08:20:46'),(7637,3,3782.34,0,0,0,0,'2026-04-26 08:30:46'),(7638,3,3782.34,0,0,0,0,'2026-04-26 08:40:46'),(7639,3,3782.34,0,0,0,0,'2026-04-26 08:50:46'),(7640,3,3782.34,0,0,0,0,'2026-04-26 09:00:46'),(7641,3,3782.34,0,0,0,0,'2026-04-26 09:10:46'),(7642,3,3782.34,0,0,0,0,'2026-04-26 09:20:46'),(7643,3,3782.34,0,0,0,0,'2026-04-26 09:30:46'),(7644,3,3782.34,0,0,0,0,'2026-04-26 09:40:46'),(7645,3,3782.34,0,0,0,0,'2026-04-26 09:50:46'),(7646,3,3782.34,0,0,0,0,'2026-04-26 10:00:46'),(7647,3,3782.34,0,0,0,0,'2026-04-26 10:10:46'),(7648,3,3782.34,0,0,0,0,'2026-04-26 10:20:46'),(7649,3,3782.34,0,0,0,0,'2026-04-26 10:30:46'),(7650,3,3782.34,0,0,0,0,'2026-04-26 10:40:46'),(7651,3,3782.34,0,0,0,0,'2026-04-26 10:50:46'),(7652,3,3782.34,0,0,0,0,'2026-04-26 11:00:46'),(7653,3,3782.34,0,0,0,0,'2026-04-26 11:10:46'),(7654,3,3782.34,0,0,0,0,'2026-04-26 11:20:46'),(7655,3,3782.34,0,0,0,0,'2026-04-26 11:30:46'),(7656,3,3782.34,0,0,0,0,'2026-04-26 11:40:46'),(7657,3,3782.34,0,0,0,0,'2026-04-26 11:50:46'),(7658,3,3782.34,0,0,0,0,'2026-04-26 12:00:46'),(7659,3,3782.34,0,0,0,0,'2026-04-26 12:10:46'),(7660,3,3782.34,0,0,0,0,'2026-04-26 12:20:46'),(7661,3,3782.34,0,0,0,0,'2026-04-26 12:30:46'),(7662,3,3782.34,0,0,0,0,'2026-04-26 12:40:46'),(7663,3,3782.34,0,0,0,0,'2026-04-26 12:50:46'),(7664,3,3782.34,0,0,0,0,'2026-04-26 13:00:46'),(7665,3,3782.34,0,0,0,0,'2026-04-26 13:10:46'),(7666,3,3782.34,0,0,0,0,'2026-04-26 13:20:46'),(7667,3,3782.34,0,0,0,0,'2026-04-26 13:30:46'),(7668,3,3782.34,0,0,0,0,'2026-04-26 13:40:46'),(7669,3,3782.34,0,0,0,0,'2026-04-26 13:50:46'),(7670,3,3782.34,0,0,0,0,'2026-04-26 14:00:46'),(7671,3,3782.34,0,0,0,0,'2026-04-26 14:10:46'),(7672,3,3782.34,0,0,0,0,'2026-04-26 14:20:46'),(7673,3,3782.34,0,0,0,0,'2026-04-26 14:30:46'),(7674,3,3782.34,0,0,0,0,'2026-04-26 14:40:46'),(7675,3,3782.34,0,0,0,0,'2026-04-26 14:50:46'),(7676,3,3782.34,0,0,0,0,'2026-04-26 15:00:46'),(7677,3,3782.34,0,0,0,0,'2026-04-26 15:10:46'),(7678,3,3782.34,0,0,0,0,'2026-04-26 15:20:46'),(7679,3,3782.34,0,0,0,0,'2026-04-26 15:30:46'),(7680,3,3782.34,0,0,0,0,'2026-04-26 15:40:46'),(7681,3,3782.34,0,0,0,0,'2026-04-26 15:50:46'),(7682,3,3782.34,0,0,0,0,'2026-04-26 16:00:46'),(7683,3,3782.34,0,0,0,0,'2026-04-26 16:10:46'),(7684,3,3782.34,0,0,0,0,'2026-04-26 16:20:46'),(7685,3,3782.34,0,0,0,0,'2026-04-26 16:30:46'),(7686,3,3782.34,0,0,0,0,'2026-04-26 16:40:46'),(7687,3,3782.34,0,0,0,0,'2026-04-26 16:50:46'),(7688,3,3782.34,0,0,0,0,'2026-04-26 17:00:46'),(7689,3,3782.34,0,0,0,0,'2026-04-26 17:10:46'),(7690,3,3782.34,0,0,0,0,'2026-04-26 17:20:46'),(7691,3,3782.34,0,0,0,0,'2026-04-26 17:30:46'),(7692,3,3782.34,0,0,0,0,'2026-04-26 17:40:46'),(7693,3,3782.34,0,0,0,0,'2026-04-26 17:50:46'),(7694,3,3782.34,0,0,0,0,'2026-04-26 18:00:46'),(7695,3,3782.34,0,0,0,0,'2026-04-26 18:10:46'),(7696,3,3782.34,0,0,0,0,'2026-04-26 18:20:46'),(7697,3,3782.34,0,0,0,0,'2026-04-26 18:30:46'),(7698,3,3782.34,0,0,0,0,'2026-04-26 18:40:46'),(7699,3,3782.34,0,0,0,0,'2026-04-26 18:50:46'),(7700,3,3782.34,0,0,0,0,'2026-04-26 19:00:46'),(7701,3,3782.34,0,0,0,0,'2026-04-26 19:10:46'),(7702,3,3782.34,0,0,0,0,'2026-04-26 19:20:46'),(7703,3,3782.34,0,0,0,0,'2026-04-26 19:30:46'),(7704,3,3782.34,0,0,0,0,'2026-04-26 19:40:46'),(7705,3,3782.34,0,0,0,0,'2026-04-26 19:50:46'),(7706,3,3782.34,0,0,0,0,'2026-04-26 20:00:46'),(7707,3,3782.34,0,0,0,0,'2026-04-26 20:10:46'),(7708,3,3782.34,0,0,0,0,'2026-04-26 20:20:46'),(7709,3,3782.34,0,0,0,0,'2026-04-26 20:30:46'),(7710,3,3782.34,0,0,0,0,'2026-04-26 20:40:46'),(7711,3,3782.34,0,0,0,0,'2026-04-26 20:50:46'),(7712,3,3782.34,0,0,0,0,'2026-04-26 21:00:46'),(7713,3,3782.34,0,0,0,0,'2026-04-26 21:10:46'),(7714,3,3782.34,0,0,0,0,'2026-04-26 21:20:46'),(7715,3,3782.34,0,0,0,0,'2026-04-26 21:30:46'),(7716,3,3782.34,0,0,0,0,'2026-04-26 21:40:46'),(7717,3,3782.34,0,0,0,0,'2026-04-26 21:50:46'),(7718,3,3782.34,0,0,0,0,'2026-04-26 22:00:46'),(7719,3,3782.34,0,0,0,0,'2026-04-26 22:10:46'),(7720,3,3782.34,0,0,0,0,'2026-04-26 22:20:46'),(7721,3,3782.34,5.899,344.5,0.86,0.959,'2026-04-26 22:30:41'),(7722,3,3782.34,5.881,358.1,0.83,0.959,'2026-04-26 22:40:41'),(7723,3,3782.34,5.865,407,0.79,0.959,'2026-04-26 22:50:41'),(7724,3,3782.34,5.899,519.6,0.68,0.959,'2026-04-26 23:00:41'),(7725,3,3782.34,5.906,539.2,0.67,0.959,'2026-04-26 23:10:41'),(7726,3,3782.34,5.945,539.8,0.7,0.96,'2026-04-26 23:20:41'),(7727,3,3782.34,6.071,4.8,11.67,0.488,'2026-04-26 23:30:41'),(7728,3,3782.34,5.918,520.1,0.67,0.96,'2026-04-26 23:40:41'),(7729,3,3782.34,5.925,103.2,2.95,0.949,'2026-04-26 23:50:41'),(7730,3,3782.34,5.901,36.2,10.25,0.835,'2026-04-27 00:00:41'),(7731,3,3782.34,5.957,462.8,0.78,0.961,'2026-04-27 00:10:41'),(7732,3,3782.34,6.023,551.8,0.7,0.96,'2026-04-27 00:20:41'),(7733,3,3782.34,5.967,559.6,0.69,0.961,'2026-04-27 00:30:41'),(7734,3,3782.34,5.988,559.6,0.69,0.961,'2026-04-27 00:40:41'),(7735,3,3782.34,5.995,558.1,0.63,0.961,'2026-04-27 00:50:41'),(7736,3,3782.34,6.047,4.8,9.08,0.495,'2026-04-27 01:00:41'),(7737,3,3782.34,6.083,3.8,9.55,1.575,'2026-04-27 01:10:41'),(7738,3,3782.34,5.974,546,0.71,0.96,'2026-04-27 01:20:41'),(7739,3,3782.34,6.009,545.1,0.71,0.96,'2026-04-27 01:30:41'),(7740,3,3782.34,5.97,544.9,0.71,0.96,'2026-04-27 01:40:41'),(7741,3,3782.34,6.005,556.1,0.7,0.961,'2026-04-27 01:50:41'),(7742,3,3782.34,6,560.6,0.66,0.961,'2026-04-27 02:00:41'),(7743,3,3782.34,6.112,4.7,9.62,0.495,'2026-04-27 02:10:41'),(7744,3,3782.34,5.969,445.8,0.71,0.96,'2026-04-27 02:20:41'),(7745,3,3782.34,5.945,545.9,0.67,0.96,'2026-04-27 02:30:41'),(7746,3,3782.34,5.998,545.8,0.66,0.96,'2026-04-27 02:40:41'),(7747,3,3782.34,6.024,544.8,0.69,0.961,'2026-04-27 02:50:41'),(7748,3,3782.34,6.049,550.8,0.72,0.961,'2026-04-27 03:00:41'),(7749,3,3782.34,6.072,4.8,9.94,0.494,'2026-04-27 03:10:41'),(7750,3,3782.34,5.9,267,0.92,0.96,'2026-04-27 03:20:41'),(7751,3,3782.34,5.952,556.3,0.61,0.96,'2026-04-27 03:30:41'),(7752,3,3782.34,5.989,556,0.65,0.961,'2026-04-27 03:40:41'),(7753,3,3782.34,6.016,555.8,0.66,0.961,'2026-04-27 03:50:41'),(7754,3,3782.34,5.998,555.7,0.68,0.96,'2026-04-27 04:00:41'),(7755,3,3782.34,6.015,547,0.74,0.961,'2026-04-27 04:10:41'),(7756,3,3782.34,6.093,4.6,10.31,0.481,'2026-04-27 04:20:41'),(7757,3,3782.34,5.9,426.5,0.73,0.96,'2026-04-27 04:30:41'),(7758,3,3782.34,5.973,535.9,0.7,0.96,'2026-04-27 04:40:41'),(7759,3,3782.34,5.992,557.2,0.74,0.961,'2026-04-27 04:50:41'),(7760,3,3782.34,5.976,557,0.72,0.96,'2026-04-27 05:00:41'),(7761,3,3782.34,5.94,542,0.78,0.961,'2026-04-27 05:10:41'),(7762,3,3782.34,6.014,4.8,8.92,0.494,'2026-04-27 05:20:41'),(7763,3,3782.34,5.917,65.5,4.74,0.924,'2026-04-27 05:30:41'),(7764,3,3782.34,5.966,497.1,0.79,0.961,'2026-04-27 05:40:41'),(7765,3,3782.34,5.941,550.3,0.73,0.961,'2026-04-27 05:50:41'),(7766,3,3782.34,5.847,550.2,0.7,0.961,'2026-04-27 06:00:41'),(7767,3,3782.34,5.85,550.1,0.71,0.961,'2026-04-27 06:10:41'),(7768,3,3782.34,5.775,237.8,1.21,0.96,'2026-04-27 06:20:41'),(7769,3,3782.34,5.969,4.8,8.77,0.501,'2026-04-27 06:30:41'),(7770,3,3782.34,5.964,3.5,7.81,1.595,'2026-04-27 06:40:41'),(7771,3,3782.34,5.885,351.3,0.73,0.961,'2026-04-27 06:50:41'),(7772,3,3782.34,5.904,482,0.67,0.961,'2026-04-27 07:00:41'),(7773,3,3782.34,5.988,517.2,0.67,0.961,'2026-04-27 07:10:41'),(7774,3,3782.34,5.889,517.2,0.75,0.961,'2026-04-27 07:20:41'),(7775,3,3782.34,5.886,178.3,1.45,0.958,'2026-04-27 07:30:41'),(7776,3,3782.34,5.833,239.3,1.2,0.96,'2026-04-27 07:40:41'),(7777,3,3782.34,5.892,498.8,0.71,0.962,'2026-04-27 07:50:41'),(7778,3,3782.34,6.091,3.8,9.63,1.567,'2026-04-27 08:00:41'),(7779,3,3782.34,5.981,470.1,0.78,0.959,'2026-04-27 08:10:41'),(7780,3,3782.34,6.086,518.9,0.79,0.959,'2026-04-27 08:20:41'),(7781,3,3782.34,6.067,518.5,0.76,0.959,'2026-04-27 08:30:41'),(7782,3,3782.34,6.083,518.4,0.76,0.96,'2026-04-27 08:40:41'),(7783,3,3782.34,6.016,518.4,0.82,0.96,'2026-04-27 08:50:41'),(7784,3,3782.34,6.107,157.7,1.83,0.956,'2026-04-27 09:00:41'),(7785,3,3782.34,6.179,4.8,9.82,0.497,'2026-04-27 09:10:41'),(7786,3,3782.34,6.1,526.3,0.93,0.96,'2026-04-27 09:20:41'),(7787,3,3782.34,6.026,440.7,0.88,0.96,'2026-04-27 09:30:41'),(7788,3,3782.34,6.103,518.4,0.79,0.96,'2026-04-27 09:40:41'),(7789,3,3782.34,6.102,518.1,0.89,0.96,'2026-04-27 09:50:41'),(7790,3,3782.34,6.105,518,0.79,0.96,'2026-04-27 10:00:41'),(7791,3,3782.34,6.041,142,2.16,0.954,'2026-04-27 10:10:41'),(7792,3,3782.34,6.07,532.4,0.79,0.96,'2026-04-27 10:20:41'),(7793,3,3782.34,5.978,531.1,0.76,0.96,'2026-04-27 10:30:41'),(7794,3,3782.34,6.009,20.4,10.36,0.731,'2026-04-27 10:40:41'),(7795,3,3782.34,0,0,0,0,'2026-04-27 10:50:46'),(7796,3,3782.34,6.071,418.5,0.9,0.959,'2026-04-27 11:00:41'),(7797,3,3782.34,6.127,532.9,0.81,0.959,'2026-04-27 11:10:41'),(7798,3,3782.34,6.089,532,0.72,0.96,'2026-04-27 11:20:41'),(7799,3,3782.34,6.027,532.3,0.81,0.959,'2026-04-27 11:30:41'),(7800,3,3782.34,6.039,173.3,1.59,0.956,'2026-04-27 11:40:41'),(7801,3,3782.34,6.088,5,10,0.498,'2026-04-27 11:50:41'),(7802,3,3782.34,6.043,450.4,0.76,0.959,'2026-04-27 12:00:41'),(7803,3,3782.34,6.1,524.8,0.68,0.958,'2026-04-27 12:10:41'),(7804,3,3782.34,6.033,524.5,0.64,0.958,'2026-04-27 12:20:41'),(7805,3,3782.34,6.117,524.3,0.73,0.958,'2026-04-27 12:30:41'),(7806,3,3782.34,6.218,4.9,9.12,0.499,'2026-04-27 12:40:41'),(7807,3,3782.34,6.17,13.4,9.37,0.747,'2026-04-27 12:50:41'),(7808,3,3782.34,6.204,528.9,0.75,0.959,'2026-04-27 13:00:41'),(7809,3,3782.34,6.144,3.4,9.44,1.602,'2026-04-27 13:10:41'),(7810,3,3782.34,6.021,524.4,0.78,0.96,'2026-04-27 13:20:41'),(7811,3,3782.34,5.993,523.6,0.75,0.96,'2026-04-27 13:30:41'),(7812,3,3782.34,5.896,523.5,0.69,0.96,'2026-04-27 13:40:41'),(7813,3,3782.34,5.957,523.8,0.72,0.96,'2026-04-27 13:50:41'),(7814,3,3782.34,5.852,123.8,2.52,0.951,'2026-04-27 14:00:41'),(7815,3,3782.34,6.02,4.5,9.86,0.473,'2026-04-27 14:10:41'),(7816,3,3782.34,6.003,519.6,0.72,0.96,'2026-04-27 14:20:41'),(7817,3,3782.34,5.962,518,0.77,0.959,'2026-04-27 14:30:41'),(7818,3,3782.34,5.963,519,0.89,0.96,'2026-04-27 14:40:41'),(7819,3,3782.34,5.978,519.1,0.74,0.959,'2026-04-27 14:50:41'),(7820,3,3782.34,5.94,160.1,1.83,0.955,'2026-04-27 15:00:41'),(7821,3,3782.34,6.028,514.7,0.83,0.96,'2026-04-27 15:10:41'),(7822,3,3782.34,6.072,515.7,0.75,0.96,'2026-04-27 15:20:41'),(7823,3,3782.34,6.046,516.4,0.81,0.96,'2026-04-27 15:30:41'),(7824,3,3782.34,5.956,515.9,0.85,0.959,'2026-04-27 15:40:41'),(7825,3,3782.34,6.033,516,0.78,0.959,'2026-04-27 15:50:41'),(7826,3,3782.34,5.946,508.6,0.77,0.959,'2026-04-27 16:00:41'),(7827,3,3782.34,0,0,0,0,'2026-04-27 16:10:46'),(7828,3,3782.34,0,0,0,0,'2026-04-27 16:12:10'),(7829,3,3782.34,0,0,0,0,'2026-04-27 16:22:10'),(7830,3,3782.34,0,0,0,0,'2026-04-27 16:32:10'),(7831,3,3782.34,0,0,0,0,'2026-04-27 16:42:10'),(7832,3,3782.34,0,0,0,0,'2026-04-27 16:52:10'),(7833,3,3782.34,0,0,0,0,'2026-04-27 17:02:10'),(7834,3,3782.34,0,0,0,0,'2026-04-27 17:12:10'),(7835,3,3782.34,0,0,0,0,'2026-04-27 17:22:10'),(7836,3,3782.34,0,0,0,0,'2026-04-27 17:32:10'),(7837,3,3782.34,0,0,0,0,'2026-04-27 17:42:10'),(7838,3,3782.34,0,0,0,0,'2026-04-27 17:52:10'),(7839,3,3782.34,0,0,0,0,'2026-04-27 18:02:10'),(7840,3,3782.34,0,0,0,0,'2026-04-27 18:12:10'),(7841,3,3782.34,0,0,0,0,'2026-04-27 18:22:10'),(7842,3,3782.34,0,0,0,0,'2026-04-27 18:32:10'),(7843,3,3782.34,0,0,0,0,'2026-04-27 18:42:10'),(7844,3,3782.34,0,0,0,0,'2026-04-27 18:52:10'),(7845,3,3782.34,0,0,0,0,'2026-04-27 19:02:10'),(7846,3,3782.34,0,0,0,0,'2026-04-27 19:12:10'),(7847,3,3782.34,0,0,0,0,'2026-04-27 19:22:10'),(7848,3,3782.34,0,0,0,0,'2026-04-27 19:32:10'),(7849,3,3782.34,0,0,0,0,'2026-04-27 19:42:10'),(7850,3,3782.34,0,0,0,0,'2026-04-27 19:52:10'),(7851,3,3782.34,0,0,0,0,'2026-04-27 20:02:10'),(7852,3,3782.34,0,0,0,0,'2026-04-27 20:12:10'),(7853,3,3782.34,0,0,0,0,'2026-04-27 20:22:10'),(7854,3,3782.34,0,0,0,0,'2026-04-27 20:32:10'),(7855,3,3782.34,0,0,0,0,'2026-04-27 20:42:10'),(7856,3,3782.34,0,0,0,0,'2026-04-27 20:52:10'),(7857,3,3782.34,0,0,0,0,'2026-04-27 21:02:10'),(7858,3,3782.34,0,0,0,0,'2026-04-27 21:12:10'),(7859,3,3782.34,0,0,0,0,'2026-04-27 21:22:10'),(7860,3,3782.34,0,0,0,0,'2026-04-27 21:32:10'),(7861,3,3782.34,0,0,0,0,'2026-04-27 21:42:10'),(7862,3,3782.34,0,0,0,0,'2026-04-27 21:52:10'),(7863,3,3782.34,0,0,0,0,'2026-04-27 22:02:10'),(7864,3,3782.34,0,0,0,0,'2026-04-27 22:12:10'),(7865,3,3782.34,0,0,0,0,'2026-04-27 22:22:10'),(7866,3,3782.34,0,0,0,0,'2026-04-27 22:32:10'),(7867,3,3782.34,0,0,0,0,'2026-04-27 22:42:10'),(7868,3,0,5.894,223.8,1.05,0.958,'2026-04-27 22:52:05'),(7869,3,0,5.847,328.2,0.83,0.96,'2026-04-27 23:02:05'),(7870,3,0,5.822,374.9,0.78,0.96,'2026-04-27 23:12:05'),(7871,3,0,5.868,530.1,0.61,0.96,'2026-04-27 23:22:05'),(7872,3,0,5.922,548.8,0.65,0.96,'2026-04-27 23:32:05'),(7873,3,0,5.884,549.3,0.64,0.961,'2026-04-27 23:42:05'),(7874,3,0,5.867,547.4,0.64,0.96,'2026-04-27 23:52:05'),(7875,3,0,5.976,547.3,0.63,0.96,'2026-04-28 00:02:05'),(7876,3,0,5.954,71.5,4.51,0.927,'2026-04-28 00:12:05'),(7877,3,0,5.881,446.7,0.71,0.96,'2026-04-28 00:22:05'),(7878,3,0,5.909,529.9,0.65,0.96,'2026-04-28 00:32:05'),(7879,3,0,5.974,529.5,0.67,0.961,'2026-04-28 00:42:05'),(7880,3,0,5.895,545,0.63,0.961,'2026-04-28 00:52:05'),(7881,3,0,6.003,4.8,13.02,0.487,'2026-04-28 01:02:05'),(7882,3,0,5.872,248,0.99,0.96,'2026-04-28 01:12:05'),(7883,3,0,5.875,385.5,0.78,0.96,'2026-04-28 01:22:05'),(7884,3,0,5.919,549.9,0.64,0.96,'2026-04-28 01:32:05'),(7885,3,0,5.898,558,0.61,0.961,'2026-04-28 01:42:05'),(7886,3,0,5.902,558,0.6,0.961,'2026-04-28 01:52:05'),(7887,3,0,5.891,557.8,0.59,0.96,'2026-04-28 02:02:05'),(7888,3,0,6.031,4.8,9.27,0.488,'2026-04-28 02:12:05'),(7889,3,0,6.055,3.5,10.59,1.597,'2026-04-28 02:22:05'),(7890,3,0,5.909,537.2,0.63,0.96,'2026-04-28 02:32:05'),(7891,3,0,5.907,539.8,0.56,0.96,'2026-04-28 02:42:05'),(7892,3,0,5.959,539.4,0.66,0.961,'2026-04-28 02:52:05'),(7893,3,0,5.993,539.2,0.64,0.961,'2026-04-28 03:02:05'),(7894,3,0,5.981,535.6,0.66,0.961,'2026-04-28 03:12:05'),(7895,3,0,6.051,5,11.56,0.541,'2026-04-28 03:22:05'),(7896,3,0,5.966,451,0.7,0.96,'2026-04-28 03:32:05'),(7897,3,0,5.962,541.7,0.68,0.961,'2026-04-28 03:42:05'),(7898,3,0,6.004,541.8,0.69,0.961,'2026-04-28 03:52:05'),(7899,3,0,5.957,542,0.67,0.961,'2026-04-28 04:02:05'),(7900,3,0,6.055,4.8,9.49,0.499,'2026-04-28 04:12:05'),(7901,3,0,5.931,554,0.69,0.96,'2026-04-28 04:22:05'),(7902,3,0,6.005,4.1,9.2,0.444,'2026-04-28 04:32:05'),(7903,3,0,5.898,440,0.72,0.961,'2026-04-28 04:42:05'),(7904,3,0,5.944,549.3,0.79,0.961,'2026-04-28 04:52:05'),(7905,3,0,5.975,553.7,0.76,0.961,'2026-04-28 05:02:05'),(7906,3,0,6.009,553.5,0.75,0.961,'2026-04-28 05:12:05'),(7907,3,0,6.115,4.9,9.19,0.498,'2026-04-28 05:22:05'),(7908,3,0,5.996,548.3,0.8,0.961,'2026-04-28 05:32:05'),(7909,3,0,5.892,460.1,0.75,0.961,'2026-04-28 05:42:05'),(7910,3,0,5.949,551.1,0.76,0.961,'2026-04-28 05:52:05'),(7911,3,0,5.927,550.5,0.72,0.961,'2026-04-28 06:02:05'),(7912,3,0,5.917,550.4,0.66,0.961,'2026-04-28 06:12:05'),(7913,3,0,5.997,4.9,6.84,0.501,'2026-04-28 06:22:05'),(7914,3,0,6.008,4.9,7.88,0.496,'2026-04-28 06:32:05'),(7915,3,0,6.016,4,6.04,0.425,'2026-04-28 06:42:05'),(7916,3,0,5.761,472.7,0.64,0.961,'2026-04-28 06:52:05'),(7973,3,349273.02,6.034,529.3,0.71,0.96,'2026-04-28 06:55:17'),(7974,3,349324.58,6.108,529.4,0.77,0.96,'2026-04-28 06:57:16'),(7975,3,349376.146,6.05,529.5,0.82,0.96,'2026-04-28 06:59:16'),(7976,3,349427.666,6.066,529.3,0.79,0.96,'2026-04-28 07:01:16'),(7977,3,349479.356,6.115,529.6,0.77,0.96,'2026-04-28 07:03:16'),(7978,3,349531.003,6.048,529.6,0.79,0.96,'2026-04-28 07:05:16'),(7979,3,349582.685,6.046,529.3,0.73,0.96,'2026-04-28 07:07:16'),(7980,3,349634.326,6.066,529.5,0.74,0.96,'2026-04-28 07:09:16'),(7981,3,349685.953,6.099,529.4,0.76,0.96,'2026-04-28 07:11:16'),(7982,3,349737.613,6.085,529.5,0.79,0.96,'2026-04-28 07:13:16'),(7983,3,349780.756,6.209,4.7,10.26,0.485,'2026-04-28 07:15:16'),(7984,3,349803.123,6.062,535.5,0.72,0.96,'2026-04-28 07:17:16'),(7985,3,349855.24,6.076,534.8,0.73,0.96,'2026-04-28 07:19:16'),(7986,3,349907.36,6.116,534.9,0.83,0.96,'2026-04-28 07:21:16'),(7987,3,349959.471,6.093,534.9,0.79,0.96,'2026-04-28 07:23:16'),(7988,3,350011.607,6.124,534.8,0.78,0.96,'2026-04-28 07:25:16'),(7989,3,350018.771,6.035,76.4,5.57,0.932,'2026-04-28 07:27:16'),(7990,3,350025.265,6.156,4.1,5.89,0.452,'2026-04-28 07:29:16'),(7991,3,350025.427,6.172,3.2,9.12,0.395,'2026-04-28 07:31:16'),(7992,3,350053.638,6.047,475.4,0.81,0.96,'2026-04-28 07:33:16'),(7993,3,350100.306,6.048,507.9,0.78,0.96,'2026-04-28 07:35:16'),(7994,3,350149.842,5.995,506.7,0.74,0.96,'2026-04-28 07:37:16'),(7995,3,350199.95,6.022,506.8,0.7,0.959,'2026-04-28 07:39:16'),(7996,3,350251.538,6.061,530.2,0.7,0.959,'2026-04-28 07:41:16'),(7997,3,350303.78,6.076,529.5,0.74,0.959,'2026-04-28 07:43:16'),(7998,3,350355.951,6.036,529.4,0.67,0.96,'2026-04-28 07:45:16'),(7999,3,350408.167,6.005,529.4,0.72,0.959,'2026-04-28 07:47:16'),(8000,3,350460.308,6.027,529.4,0.76,0.96,'2026-04-28 07:49:16'),(8001,3,350512.388,6.038,529.3,0.73,0.96,'2026-04-28 07:51:16'),(8002,3,350564.39,6.076,529.2,0.72,0.96,'2026-04-28 07:53:16'),(8003,3,350616.606,6.093,529.3,0.68,0.96,'2026-04-28 07:55:16'),(8004,3,350668.824,6.013,529.4,0.72,0.96,'2026-04-28 07:57:16'),(8005,3,350721.105,6.031,529.2,0.75,0.96,'2026-04-28 07:59:16'),(8006,3,350773.293,6.056,529.5,0.73,0.96,'2026-04-28 08:01:16'),(8007,3,350825.47,6.015,529.3,0.68,0.959,'2026-04-28 08:03:16'),(8008,3,350877.598,6.025,529.2,0.74,0.959,'2026-04-28 08:05:16'),(8009,3,350929.741,5.932,529.4,0.77,0.959,'2026-04-28 08:07:16'),(8010,3,350981.915,5.931,529.3,0.74,0.96,'2026-04-28 08:09:16'),(8011,3,351034.105,5.956,529.4,0.76,0.96,'2026-04-28 08:11:16'),(8012,3,351086.272,5.953,529.4,0.73,0.96,'2026-04-28 08:13:16'),(8013,3,351138.443,5.992,529.3,0.8,0.96,'2026-04-28 08:15:16'),(8014,3,351190.783,6.089,529.4,0.74,0.96,'2026-04-28 08:17:16'),(8015,3,351220.244,6.212,4.7,8.89,0.489,'2026-04-28 08:19:16'),(8016,3,351248.837,6.066,524,0.77,0.96,'2026-04-28 08:21:16'),(8017,3,351300.659,6.071,523.7,0.74,0.959,'2026-04-28 08:23:16'),(8018,3,351352.516,6.032,523.7,0.73,0.959,'2026-04-28 08:25:16'),(8019,3,351404.339,5.929,523.3,0.72,0.959,'2026-04-28 08:27:16'),(8020,3,351435.594,5.993,517.7,0.73,0.959,'2026-04-28 08:29:16'),(8021,3,351486.988,5.965,517.1,0.7,0.96,'2026-04-28 08:31:16'),(8022,3,351538.42,6.01,517,0.69,0.959,'2026-04-28 08:33:16'),(8023,3,351552.2,6.092,4.8,9.71,0.492,'2026-04-28 08:35:16'),(8024,3,351554.998,5.954,368.8,0.84,0.959,'2026-04-28 08:37:16'),(8025,3,351554.998,0,0,0,0,'2026-04-28 08:39:21'),(8026,3,351554.998,0,0,0,0,'2026-04-28 08:41:21'),(8027,3,351554.998,0,0,0,0,'2026-04-28 08:43:21'),(8028,3,351554.998,0,0,0,0,'2026-04-28 08:45:21'),(8029,3,351554.998,0,0,0,0,'2026-04-28 08:47:21'),(8030,3,351554.998,0,0,0,0,'2026-04-28 08:49:21'),(8031,3,351554.998,0,0,0,0,'2026-04-28 08:51:21'),(8032,3,351554.998,0,0,0,0,'2026-04-28 08:53:21'),(8033,3,351554.998,0,0,0,0,'2026-04-28 08:55:21'),(8034,3,351554.998,0,0,0,0,'2026-04-28 08:57:21'),(8035,3,351554.998,0,0,0,0,'2026-04-28 08:59:21'),(8036,3,351554.998,0,0,0,0,'2026-04-28 09:01:21'),(8037,3,351554.998,0,0,0,0,'2026-04-28 09:03:21'),(8038,3,351554.998,0,0,0,0,'2026-04-28 09:05:21'),(8039,3,351554.998,0,0,0,0,'2026-04-28 09:07:21'),(8040,3,351554.998,0,0,0,0,'2026-04-28 09:09:21'),(8041,3,351554.998,0,0,0,0,'2026-04-28 09:11:21'),(8042,3,351554.998,0,0,0,0,'2026-04-28 09:13:21'),(8043,3,351554.998,0,0,0,0,'2026-04-28 09:15:21'),(8044,3,351554.998,0,0,0,0,'2026-04-28 09:17:21'),(8045,3,351554.998,0,0,0,0,'2026-04-28 09:19:21'),(8046,3,351554.998,0,0,0,0,'2026-04-28 09:21:21'),(8047,3,351554.998,0,0,0,0,'2026-04-28 09:23:21'),(8048,3,351554.998,0,0,0,0,'2026-04-28 09:25:21'),(8049,3,351554.998,0,0,0,0,'2026-04-28 09:27:21'),(8050,3,351554.998,0,0,0,0,'2026-04-28 09:29:21'),(8051,3,351554.998,0,0,0,0,'2026-04-28 09:31:21'),(8052,3,351554.998,0,0,0,0,'2026-04-28 09:33:21'),(8053,3,351554.998,0,0,0,0,'2026-04-28 09:35:21'),(8054,3,351554.998,0,0,0,0,'2026-04-28 09:37:21'),(8055,3,351554.998,0,0,0,0,'2026-04-28 09:39:21'),(8056,3,351554.998,0,0,0,0,'2026-04-28 09:41:21'),(8057,3,351554.998,0,0,0,0,'2026-04-28 09:43:21'),(8058,3,351554.998,0,0,0,0,'2026-04-28 09:45:21'),(8059,3,351554.998,0,0,0,0,'2026-04-28 09:47:21'),(8060,3,351554.998,0,0,0,0,'2026-04-28 09:49:21'),(8061,3,351554.998,0,0,0,0,'2026-04-28 09:51:21'),(8062,3,351554.998,0,0,0,0,'2026-04-28 09:53:21'),(8063,3,351554.998,0,0,0,0,'2026-04-28 09:55:21'),(8064,3,351554.998,0,0,0,0,'2026-04-28 09:57:21'),(8065,3,351554.998,0,0,0,0,'2026-04-28 09:59:21'),(8066,3,351554.998,0,0,0,0,'2026-04-28 10:01:21'),(8067,3,351554.998,0,0,0,0,'2026-04-28 10:03:21'),(8068,3,351554.998,0,0,0,0,'2026-04-28 10:05:21'),(8069,3,351554.998,0,0,0,0,'2026-04-28 10:07:21'),(8070,3,351554.998,0,0,0,0,'2026-04-28 10:09:21'),(8071,3,351554.998,0,0,0,0,'2026-04-28 10:11:21'),(8072,3,351554.998,0,0,0,0,'2026-04-28 10:13:21'),(8073,3,351554.998,0,0,0,0,'2026-04-28 10:15:21'),(8074,3,351554.998,0,0,0,0,'2026-04-28 10:17:21'),(8075,3,351554.998,0,0,0,0,'2026-04-28 10:19:21'),(8076,3,351554.998,0,0,0,0,'2026-04-28 10:21:21'),(8077,3,351554.998,0,0,0,0,'2026-04-28 10:23:21'),(8078,3,351554.998,0,0,0,0,'2026-04-28 10:25:21'),(8079,3,351554.998,0,0,0,0,'2026-04-28 10:27:21'),(8080,3,351554.998,0,0,0,0,'2026-04-28 10:29:21'),(8081,3,351554.998,0,0,0,0,'2026-04-28 10:31:21'),(8082,3,351554.998,0,0,0,0,'2026-04-28 10:33:21'),(8083,3,351554.998,0,0,0,0,'2026-04-28 10:35:21'),(8084,3,351554.998,0,0,0,0,'2026-04-28 10:37:21'),(8085,3,351554.998,0,0,0,0,'2026-04-28 10:39:21'),(8086,3,351554.998,0,0,0,0,'2026-04-28 10:41:21'),(8087,3,351554.998,0,0,0,0,'2026-04-28 10:43:21'),(8088,3,351554.998,0,0,0,0,'2026-04-28 10:45:21'),(8089,3,351554.998,0,0,0,0,'2026-04-28 10:47:21'),(8090,3,351554.998,0,0,0,0,'2026-04-28 10:49:21'),(8091,3,351554.998,0,0,0,0,'2026-04-28 10:51:21'),(8092,3,351554.998,0,0,0,0,'2026-04-28 10:53:21'),(8093,3,351554.998,0,0,0,0,'2026-04-28 10:55:21'),(8094,3,351554.998,0,0,0,0,'2026-04-28 10:57:21'),(8095,3,351554.998,0,0,0,0,'2026-04-28 10:59:21'),(8096,3,351554.998,0,0,0,0,'2026-04-28 11:01:21'),(8097,3,351554.998,0,0,0,0,'2026-04-28 11:03:21'),(8098,3,351554.998,0,0,0,0,'2026-04-28 11:05:21'),(8099,3,351554.998,0,0,0,0,'2026-04-28 11:07:21'),(8100,3,351554.998,0,0,0,0,'2026-04-28 11:09:21'),(8101,3,351554.998,0,0,0,0,'2026-04-28 11:11:21'),(8102,3,351554.998,0,0,0,0,'2026-04-28 11:13:21'),(8103,3,351554.998,0,0,0,0,'2026-04-28 11:15:21'),(8104,3,351554.998,0,0,0,0,'2026-04-28 11:17:21'),(8105,3,351554.998,0,0,0,0,'2026-04-28 11:19:21'),(8106,3,351554.998,0,0,0,0,'2026-04-28 11:21:21'),(8107,3,351554.998,0,0,0,0,'2026-04-28 11:23:21'),(8108,3,351554.998,0,0,0,0,'2026-04-28 11:25:21'),(8109,3,351554.998,0,0,0,0,'2026-04-28 11:27:21'),(8110,3,351554.998,0,0,0,0,'2026-04-28 11:29:21'),(8111,3,351554.998,0,0,0,0,'2026-04-28 11:31:21'),(8112,3,351554.998,0,0,0,0,'2026-04-28 11:33:21'),(8113,3,351554.998,0,0,0,0,'2026-04-28 11:35:21'),(8114,3,351554.998,0,0,0,0,'2026-04-28 11:37:21'),(8115,3,351554.998,0,0,0,0,'2026-04-28 11:39:21'),(8116,3,351554.998,0,0,0,0,'2026-04-28 11:41:21'),(8117,3,351554.998,0,0,0,0,'2026-04-28 11:43:21'),(8118,3,351554.998,0,0,0,0,'2026-04-28 11:45:21'),(8119,3,351554.998,0,0,0,0,'2026-04-28 11:47:21'),(8120,3,351554.998,0,0,0,0,'2026-04-28 11:49:21'),(8121,3,351554.998,0,0,0,0,'2026-04-28 11:51:21'),(8122,3,351554.998,0,0,0,0,'2026-04-28 11:53:21'),(8123,3,351554.998,0,0,0,0,'2026-04-28 11:55:21'),(8124,3,351554.998,0,0,0,0,'2026-04-28 11:57:21'),(8125,3,351554.998,0,0,0,0,'2026-04-28 11:59:21'),(8126,3,351554.998,0,0,0,0,'2026-04-28 12:01:21'),(8127,3,351554.998,0,0,0,0,'2026-04-28 12:03:21'),(8128,3,351554.998,0,0,0,0,'2026-04-28 12:05:21'),(8129,3,351554.998,0,0,0,0,'2026-04-28 12:07:21'),(8130,3,351554.998,0,0,0,0,'2026-04-28 12:09:21'),(8131,3,351554.998,0,0,0,0,'2026-04-28 12:11:21'),(8132,3,351554.998,0,0,0,0,'2026-04-28 12:13:21'),(8133,3,351554.998,0,0,0,0,'2026-04-28 12:15:21'),(8134,3,351554.998,0,0,0,0,'2026-04-28 12:17:21'),(8135,3,351554.998,0,0,0,0,'2026-04-28 12:19:21'),(8136,3,351554.998,0,0,0,0,'2026-04-28 12:21:21'),(8137,3,351554.998,0,0,0,0,'2026-04-28 12:23:21'),(8138,3,351554.998,0,0,0,0,'2026-04-28 12:25:21'),(8139,3,351554.998,0,0,0,0,'2026-04-28 12:27:21'),(8140,3,351554.998,0,0,0,0,'2026-04-28 12:29:21'),(8141,3,351554.998,0,0,0,0,'2026-04-28 12:31:21'),(8142,3,351554.998,0,0,0,0,'2026-04-28 12:33:21'),(8143,3,351554.998,0,0,0,0,'2026-04-28 12:35:21'),(8144,3,351554.998,0,0,0,0,'2026-04-28 12:37:21'),(8145,3,351554.998,0,0,0,0,'2026-04-28 12:39:21'),(8146,3,351554.998,0,0,0,0,'2026-04-28 12:41:21'),(8147,3,351554.998,0,0,0,0,'2026-04-28 12:43:21'),(8148,3,351554.998,0,0,0,0,'2026-04-28 12:45:21'),(8149,3,351554.998,0,0,0,0,'2026-04-28 12:47:21'),(8150,3,351554.998,0,0,0,0,'2026-04-28 12:49:21'),(8151,3,351554.998,0,0,0,0,'2026-04-28 12:51:21'),(8152,3,351554.998,0,0,0,0,'2026-04-28 12:53:21'),(8153,3,351554.998,0,0,0,0,'2026-04-28 12:55:21'),(8154,3,351554.998,0,0,0,0,'2026-04-28 12:57:21'),(8155,3,351554.998,0,0,0,0,'2026-04-28 12:59:21'),(8156,3,351554.998,0,0,0,0,'2026-04-28 13:01:21'),(8157,3,351554.998,0,0,0,0,'2026-04-28 13:03:21'),(8158,3,351554.998,0,0,0,0,'2026-04-28 13:05:21'),(8159,3,351554.998,0,0,0,0,'2026-04-28 13:07:21'),(8160,3,351554.998,0,0,0,0,'2026-04-28 13:09:21'),(8161,3,351554.998,0,0,0,0,'2026-04-28 13:11:21'),(8162,3,351554.998,0,0,0,0,'2026-04-28 13:13:21'),(8163,3,351554.998,0,0,0,0,'2026-04-28 13:15:21'),(8164,3,351554.998,0,0,0,0,'2026-04-28 13:17:21'),(8165,3,351554.998,0,0,0,0,'2026-04-28 13:19:21'),(8166,3,351554.998,0,0,0,0,'2026-04-28 13:21:21'),(8167,3,351554.998,0,0,0,0,'2026-04-28 13:23:21'),(8168,3,351554.998,0,0,0,0,'2026-04-28 13:25:21'),(8169,3,351554.998,0,0,0,0,'2026-04-28 13:27:21'),(8170,3,351554.998,0,0,0,0,'2026-04-28 13:29:21'),(8171,3,351554.998,0,0,0,0,'2026-04-28 13:31:21'),(8172,3,351554.998,0,0,0,0,'2026-04-28 13:33:21'),(8173,3,351554.998,0,0,0,0,'2026-04-28 13:35:21'),(8174,3,351554.998,0,0,0,0,'2026-04-28 13:37:21'),(8175,3,351554.998,0,0,0,0,'2026-04-28 13:39:21'),(8176,3,351554.998,0,0,0,0,'2026-04-28 13:41:21'),(8177,3,351554.998,0,0,0,0,'2026-04-28 13:43:21'),(8178,3,351554.998,0,0,0,0,'2026-04-28 13:45:21'),(8179,3,351554.998,0,0,0,0,'2026-04-28 13:47:21'),(8180,3,351554.998,0,0,0,0,'2026-04-28 13:49:21'),(8181,3,351554.998,0,0,0,0,'2026-04-28 13:51:21'),(8182,3,351554.998,0,0,0,0,'2026-04-28 13:53:21'),(8183,3,351554.998,0,0,0,0,'2026-04-28 13:55:21'),(8184,3,351554.998,0,0,0,0,'2026-04-28 13:57:21'),(8185,3,351554.998,0,0,0,0,'2026-04-28 13:59:21'),(8186,3,351554.998,0,0,0,0,'2026-04-28 14:01:21'),(8187,3,351554.998,0,0,0,0,'2026-04-28 14:03:21'),(8188,3,351554.998,0,0,0,0,'2026-04-28 14:05:21'),(8189,3,351554.998,0,0,0,0,'2026-04-28 14:07:21'),(8190,3,351554.998,0,0,0,0,'2026-04-28 14:09:21'),(8191,3,351554.998,0,0,0,0,'2026-04-28 14:11:21'),(8192,3,351554.998,0,0,0,0,'2026-04-28 14:13:21'),(8193,3,351554.998,0,0,0,0,'2026-04-28 14:15:21'),(8194,3,351554.998,0,0,0,0,'2026-04-28 14:17:21'),(8195,3,351554.998,0,0,0,0,'2026-04-28 14:19:21'),(8196,3,351554.998,0,0,0,0,'2026-04-28 14:21:21'),(8197,3,351554.998,0,0,0,0,'2026-04-28 14:23:21'),(8198,3,351554.998,0,0,0,0,'2026-04-28 14:25:21'),(8199,3,351554.998,0,0,0,0,'2026-04-28 14:27:21'),(8200,3,351554.998,0,0,0,0,'2026-04-28 14:29:21'),(8201,3,351554.998,0,0,0,0,'2026-04-28 14:31:21'),(8202,3,351554.998,0,0,0,0,'2026-04-28 14:33:21'),(8203,3,351554.998,0,0,0,0,'2026-04-28 14:35:21'),(8204,3,351554.998,0,0,0,0,'2026-04-28 14:37:21'),(8205,3,351554.998,0,0,0,0,'2026-04-28 14:39:21'),(8206,3,351554.998,0,0,0,0,'2026-04-28 14:41:21'),(8207,3,351554.998,0,0,0,0,'2026-04-28 14:43:21'),(8208,3,351554.998,0,0,0,0,'2026-04-28 14:45:21'),(8209,3,351554.998,0,0,0,0,'2026-04-28 14:47:21'),(8210,3,351554.998,0,0,0,0,'2026-04-28 14:49:21'),(8211,3,351554.998,0,0,0,0,'2026-04-28 14:51:21'),(8212,3,351554.998,0,0,0,0,'2026-04-28 14:53:21'),(8213,3,351554.998,0,0,0,0,'2026-04-28 14:55:21'),(8214,3,351554.998,0,0,0,0,'2026-04-28 14:57:21'),(8215,3,351554.998,0,0,0,0,'2026-04-28 14:59:21'),(8216,3,351554.998,0,0,0,0,'2026-04-28 15:01:21'),(8217,3,351554.998,0,0,0,0,'2026-04-28 15:03:21'),(8218,3,351554.998,0,0,0,0,'2026-04-28 15:05:21'),(8219,3,351554.998,0,0,0,0,'2026-04-28 15:07:21'),(8220,3,351561.18,6.356,164.8,1.48,0.957,'2026-04-28 15:09:16'),(8221,3,351582.5,6.202,256.6,1.08,0.959,'2026-04-28 15:11:16'),(8222,3,351607.849,5.968,256.5,0.99,0.96,'2026-04-28 15:13:16'),(8223,3,351633.19,5.926,256.4,1.01,0.96,'2026-04-28 15:15:16'),(8224,3,351666.117,5.933,338.4,0.89,0.961,'2026-04-28 15:17:16'),(8225,3,351699.32,5.994,338.2,0.87,0.961,'2026-04-28 15:19:16'),(8226,3,351732.487,5.929,338.6,0.91,0.961,'2026-04-28 15:21:16'),(8227,3,351765.766,5.958,338.3,0.9,0.961,'2026-04-28 15:23:16'),(8228,3,351798.955,5.916,338.7,0.9,0.961,'2026-04-28 15:25:16'),(8229,3,351834.016,5.945,371.6,0.82,0.961,'2026-04-28 15:27:16'),(8230,3,351870.497,5.947,371.8,0.84,0.961,'2026-04-28 15:29:16'),(8231,3,351909.359,5.907,404.8,0.84,0.961,'2026-04-28 15:31:16'),(8232,3,351952.117,5.948,436.8,0.78,0.961,'2026-04-28 15:33:16'),(8233,3,351997.252,5.936,476.9,0.77,0.961,'2026-04-28 15:35:16'),(8234,3,352043.87,5.925,476.9,0.74,0.961,'2026-04-28 15:37:16'),(8235,3,352090.414,5.931,477.1,0.74,0.961,'2026-04-28 15:39:16'),(8236,3,352140.824,5.951,527.4,0.75,0.961,'2026-04-28 15:41:16'),(8237,3,352192.254,5.969,527.1,0.78,0.961,'2026-04-28 15:43:16'),(8238,3,352244.864,5.921,539.7,0.74,0.961,'2026-04-28 15:45:16'),(8239,3,352298.25,5.891,539.8,0.69,0.961,'2026-04-28 15:47:16'),(8240,3,352351.69,5.899,539.8,0.76,0.961,'2026-04-28 15:49:16'),(8241,3,352405.117,5.881,539.5,0.78,0.961,'2026-04-28 15:51:17'),(8242,3,352458.528,5.863,540,0.79,0.96,'2026-04-28 15:53:16'),(8243,3,352511.942,5.852,539.8,0.76,0.96,'2026-04-28 15:55:17'),(8244,3,352565.402,5.862,540,0.77,0.96,'2026-04-28 15:57:16'),(8245,3,352618.891,5.913,540.2,0.71,0.961,'2026-04-28 15:59:16'),(8246,3,352672.452,5.903,540.2,0.75,0.96,'2026-04-28 16:01:16'),(8247,3,352726.058,5.888,540.5,0.77,0.961,'2026-04-28 16:03:16'),(8248,3,352779.606,5.878,540.3,0.74,0.961,'2026-04-28 16:05:16'),(8249,3,352833.097,5.911,540.4,0.75,0.961,'2026-04-28 16:07:16'),(8250,3,352886.677,5.902,540.5,0.76,0.961,'2026-04-28 16:09:16'),(8251,3,352903.911,6.011,4.8,12.16,0.491,'2026-04-28 16:11:16'),(8252,3,352946.041,5.902,549,0.73,0.961,'2026-04-28 16:13:16'),(8253,3,353000.161,5.937,548.6,0.76,0.961,'2026-04-28 16:15:16'),(8254,3,353054.395,5.913,548.8,0.73,0.961,'2026-04-28 16:17:17'),(8255,3,353108.649,5.904,548.7,0.74,0.961,'2026-04-28 16:19:16'),(8256,3,353162.962,5.906,548.8,0.76,0.961,'2026-04-28 16:21:17'),(8257,3,353217.203,5.923,548.7,0.75,0.961,'2026-04-28 16:23:16'),(8258,3,353271.423,5.926,549,0.78,0.961,'2026-04-28 16:25:16'),(8259,3,353325.667,5.897,548.9,0.76,0.961,'2026-04-28 16:27:16'),(8260,3,353380.229,5.94,548.9,0.74,0.961,'2026-04-28 16:29:16'),(8261,3,353389.143,6.035,4.9,12.37,0.496,'2026-04-28 16:31:16'),(8262,3,353389.439,6.019,4.8,10.79,0.494,'2026-04-28 16:33:16'),(8263,3,353389.684,5.984,4.7,12.74,0.493,'2026-04-28 16:35:16'),(8264,3,353389.914,5.995,4.4,12.31,0.468,'2026-04-28 16:37:16'),(8265,3,353390.112,6.005,3.9,11.75,1.569,'2026-04-28 16:39:16'),(8266,3,353390.273,6.005,3.4,13.69,1.602,'2026-04-28 16:41:16'),(8267,3,353398.889,5.816,266.5,0.98,0.96,'2026-04-28 16:43:16'),(8268,3,353429.547,5.837,365.8,0.84,0.961,'2026-04-28 16:45:16'),(8269,3,353466.229,5.868,365.8,0.86,0.961,'2026-04-28 16:47:16'),(8270,3,353502.925,5.86,423.7,0.84,0.961,'2026-04-28 16:49:16'),(8271,3,353545.012,5.848,423.6,0.82,0.961,'2026-04-28 16:51:16'),(8272,3,353587.124,5.817,423.5,0.8,0.961,'2026-04-28 16:53:17'),(8273,3,353630.577,5.825,535.3,0.75,0.961,'2026-04-28 16:55:16'),(8274,3,353683.634,5.822,533.9,0.74,0.961,'2026-04-28 16:57:16'),(8275,3,353736.674,5.886,534.2,0.77,0.961,'2026-04-28 16:59:16'),(8276,3,353789.747,5.852,534.1,0.74,0.961,'2026-04-28 17:01:16'),(8277,3,353843.679,5.871,544.5,0.72,0.961,'2026-04-28 17:03:16'),(8278,3,353897.772,5.895,544.7,0.76,0.961,'2026-04-28 17:05:17'),(8279,3,353951.314,5.921,544.3,0.75,0.961,'2026-04-28 17:07:16'),(8280,3,354005.224,5.934,544.3,0.73,0.961,'2026-04-28 17:09:17'),(8281,3,354059.121,5.913,544.5,0.75,0.961,'2026-04-28 17:11:16'),(8282,3,354113.378,5.937,544.4,0.73,0.961,'2026-04-28 17:13:16'),(8283,3,354166.713,5.974,544.3,0.74,0.961,'2026-04-28 17:15:16'),(8284,3,354220.913,5.975,544.4,0.8,0.961,'2026-04-28 17:17:16'),(8285,3,354274.679,5.964,544.3,0.76,0.961,'2026-04-28 17:19:16'),(8286,3,354328.46,6.023,544.6,0.76,0.961,'2026-04-28 17:21:17'),(8287,3,354367.013,6.084,4.9,11.05,0.493,'2026-04-28 17:23:16'),(8288,3,354375.503,5.933,127.1,2.41,0.953,'2026-04-28 17:25:16'),(8289,3,354426.087,5.937,549.7,0.79,0.961,'2026-04-28 17:27:16'),(8290,3,354480.309,5.97,549.5,0.72,0.961,'2026-04-28 17:29:17'),(8291,3,354534.466,5.951,549.4,0.67,0.961,'2026-04-28 17:31:16'),(8292,3,354588.66,5.922,549.2,0.72,0.961,'2026-04-28 17:33:16'),(8293,3,354642.75,5.952,549.3,0.72,0.961,'2026-04-28 17:35:16'),(8294,3,354661.653,5.951,551.4,0.74,0.961,'2026-04-28 17:37:16'),(8295,3,354715.879,5.923,549.4,0.72,0.961,'2026-04-28 17:39:16'),(8296,3,354770.04,5.93,549.3,0.71,0.961,'2026-04-28 17:41:16'),(8297,3,354823.795,5.962,549.4,0.64,0.961,'2026-04-28 17:43:16'),(8298,3,354862.566,6.07,4.9,11.51,0.494,'2026-04-28 17:45:16'),(8299,3,354862.815,6.055,4.8,12.03,0.492,'2026-04-28 17:47:17'),(8300,3,354863.049,6.03,4.7,11.48,0.482,'2026-04-28 17:49:16'),(8301,3,354863.263,6.027,4.3,11.25,0.455,'2026-04-28 17:51:17'),(8302,3,354863.442,6.04,3.7,9.74,0.418,'2026-04-28 17:53:16'),(8303,3,354863.602,6.032,4.6,10.36,0.464,'2026-04-28 17:55:16'),(8304,3,354892.449,5.874,338.8,0.83,0.961,'2026-04-28 17:57:16'),(8305,3,354928.5,5.876,388.1,0.83,0.961,'2026-04-28 17:59:16'),(8306,3,354967.003,5.911,388.3,0.78,0.961,'2026-04-28 18:01:16'),(8307,3,355010.962,5.94,464.6,0.74,0.961,'2026-04-28 18:03:16'),(8308,3,355056.457,5.878,464.5,0.76,0.961,'2026-04-28 18:05:16'),(8309,3,355105.444,5.914,541.1,0.69,0.961,'2026-04-28 18:07:16'),(8310,3,355159.105,5.94,540.8,0.69,0.961,'2026-04-28 18:09:16'),(8311,3,355211.9,5.991,540.9,0.71,0.961,'2026-04-28 18:11:16'),(8312,3,355265.072,5.934,540.5,0.71,0.961,'2026-04-28 18:13:16'),(8313,3,355318.629,5.924,540.4,0.72,0.961,'2026-04-28 18:15:17'),(8314,3,355371.721,5.949,540.2,0.71,0.961,'2026-04-28 18:17:17'),(8315,3,355424.88,5.906,540.3,0.71,0.961,'2026-04-28 18:19:17'),(8316,3,355478.089,5.936,540.2,0.7,0.961,'2026-04-28 18:21:16'),(8317,3,355531.251,5.907,540.3,0.72,0.961,'2026-04-28 18:23:16'),(8318,3,355584.396,5.894,540.4,0.69,0.961,'2026-04-28 18:25:17'),(8319,3,355637.516,5.929,540.3,0.73,0.961,'2026-04-28 18:27:16'),(8320,3,355690.578,5.956,540.4,0.72,0.961,'2026-04-28 18:29:17'),(8321,3,355743.723,5.963,540.2,0.68,0.961,'2026-04-28 18:31:17'),(8322,3,355796.867,5.962,540.3,0.73,0.961,'2026-04-28 18:33:17'),(8323,3,355822.518,6.016,4.8,11.98,0.496,'2026-04-28 18:35:17'),(8324,3,355840.376,5.934,550.5,0.72,0.961,'2026-04-28 18:37:16'),(8325,3,355894.576,5.945,549.7,0.69,0.961,'2026-04-28 18:39:17'),(8326,3,355948.81,5.966,549.6,0.73,0.961,'2026-04-28 18:41:16'),(8327,3,356003.017,5.969,549.4,0.64,0.961,'2026-04-28 18:43:16'),(8328,3,356057.217,5.965,549.9,0.72,0.961,'2026-04-28 18:45:17'),(8329,3,356111.49,5.948,549.5,0.67,0.961,'2026-04-28 18:47:17'),(8330,3,356165.798,5.949,549.7,0.67,0.961,'2026-04-28 18:49:16'),(8331,3,356202.802,6.014,4.9,10.48,0.495,'2026-04-28 18:51:17'),(8332,3,356218.631,5.888,372.4,0.78,0.961,'2026-04-28 18:53:17'),(8333,3,356255.679,5.883,372.4,0.78,0.961,'2026-04-28 18:55:16'),(8334,3,356256.933,5.984,4.8,10.64,0.496,'2026-04-28 18:57:17'),(8335,3,356257.18,5.951,4.6,10.66,0.481,'2026-04-28 18:59:16'),(8336,3,356257.412,5.976,4.6,10.85,0.477,'2026-04-28 19:01:16'),(8337,3,356257.623,5.95,4.2,10.75,0.45,'2026-04-28 19:03:17'),(8338,3,356257.797,5.968,3.6,8.34,1.592,'2026-04-28 19:05:16'),(8339,3,356262.707,5.819,345.8,0.82,0.961,'2026-04-28 19:07:16'),(8340,3,356297.41,5.753,345.5,0.77,0.961,'2026-04-28 19:09:16'),(8341,3,356336.739,5.853,423.4,0.73,0.961,'2026-04-28 19:11:17'),(8342,3,356378.978,5.847,423.3,0.74,0.961,'2026-04-28 19:13:16'),(8343,3,356423.046,5.853,469.6,0.7,0.961,'2026-04-28 19:15:16'),(8344,3,356471.183,5.88,535.5,0.68,0.961,'2026-04-28 19:17:17'),(8345,3,356524.495,5.889,534.8,0.66,0.961,'2026-04-28 19:19:17'),(8346,3,356577.877,5.868,535.2,0.66,0.961,'2026-04-28 19:21:17'),(8347,3,356633.586,5.881,560.9,0.68,0.961,'2026-04-28 19:23:17'),(8348,3,356689.48,5.861,560.8,0.7,0.96,'2026-04-28 19:25:17'),(8349,3,356745.378,5.835,560.8,0.66,0.961,'2026-04-28 19:27:17'),(8350,3,356801.288,5.868,560.8,0.7,0.961,'2026-04-28 19:29:17'),(8351,3,356857.305,5.85,560.8,0.7,0.961,'2026-04-28 19:31:17'),(8352,3,356913.304,5.914,560.7,0.67,0.961,'2026-04-28 19:33:17'),(8353,3,356969.293,5.872,560.9,0.67,0.961,'2026-04-28 19:35:17'),(8354,3,357025.331,5.856,560.7,0.69,0.961,'2026-04-28 19:37:17'),(8355,3,357081.276,5.882,560.8,0.7,0.961,'2026-04-28 19:39:17'),(8356,3,357137.219,5.896,560.8,0.68,0.961,'2026-04-28 19:41:17'),(8357,3,357193.15,5.892,560.8,0.69,0.961,'2026-04-28 19:43:17'),(8358,3,357248.979,5.902,560.7,0.74,0.961,'2026-04-28 19:45:16'),(8359,3,357304.823,5.867,560.7,0.71,0.961,'2026-04-28 19:47:17'),(8360,3,357352.64,5.951,5,11.38,0.498,'2026-04-28 19:49:17'),(8361,3,357352.895,5.932,4.9,11.43,0.497,'2026-04-28 19:51:16'),(8362,3,357383.59,5.841,346.8,0.84,0.961,'2026-04-28 19:53:16'),(8363,3,357418.402,5.843,346.8,0.84,0.961,'2026-04-28 19:55:17'),(8364,3,357460.382,5.831,466,0.74,0.961,'2026-04-28 19:57:17'),(8365,3,357506.972,5.831,465.8,0.73,0.961,'2026-04-28 19:59:17'),(8366,3,357553.669,5.823,465.7,0.74,0.961,'2026-04-28 20:01:17'),(8367,3,357558.252,5.934,4.9,10.47,0.497,'2026-04-28 20:03:17'),(8368,3,357558.506,5.948,4.9,9.75,0.496,'2026-04-28 20:05:17'),(8369,3,357558.753,5.946,4.8,11.03,0.489,'2026-04-28 20:07:17'),(8370,3,357558.984,5.957,4.4,10.48,0.465,'2026-04-28 20:09:17'),(8371,3,357559.189,5.948,4,9.55,0.436,'2026-04-28 20:11:17'),(8372,3,357559.358,5.976,3.6,9.83,1.596,'2026-04-28 20:13:17'),(8373,3,357575.073,5.767,384.4,0.75,0.961,'2026-04-28 20:15:17'),(8374,3,357613.708,5.796,384.3,0.82,0.961,'2026-04-28 20:17:17'),(8375,3,357656.467,5.805,450.3,0.8,0.961,'2026-04-28 20:19:17'),(8376,3,357701.565,5.797,449.8,0.75,0.961,'2026-04-28 20:21:17'),(8377,3,357749.157,5.805,488.5,0.75,0.961,'2026-04-28 20:23:17'),(8378,3,357801.016,5.845,531.3,0.71,0.961,'2026-04-28 20:25:17'),(8379,3,357853.965,5.857,531.4,0.73,0.961,'2026-04-28 20:27:17'),(8380,3,357907.347,5.846,560.6,0.74,0.961,'2026-04-28 20:29:17'),(8381,3,357963.338,5.828,560.4,0.71,0.961,'2026-04-28 20:31:17'),(8382,3,358019.264,5.834,560,0.72,0.961,'2026-04-28 20:33:17'),(8383,3,358075.242,5.862,560,0.7,0.961,'2026-04-28 20:35:17'),(8384,3,358131.206,5.851,560.1,0.71,0.961,'2026-04-28 20:37:17'),(8385,3,358187.124,5.847,559.8,0.73,0.961,'2026-04-28 20:39:17'),(8386,3,358243.04,5.87,559.8,0.73,0.961,'2026-04-28 20:41:17'),(8387,3,358298.973,5.865,559.7,0.7,0.961,'2026-04-28 20:43:17'),(8388,3,358354.92,5.862,559.8,0.7,0.961,'2026-04-28 20:45:17'),(8389,3,358410.884,5.86,559.8,0.69,0.961,'2026-04-28 20:47:17'),(8390,3,358466.796,5.857,559.7,0.65,0.961,'2026-04-28 20:49:17'),(8391,3,358522.728,5.857,559.7,0.71,0.961,'2026-04-28 20:51:17'),(8392,3,358539.758,5.785,536.8,0.63,0.961,'2026-04-28 20:53:17'),(8393,3,358593.496,5.867,535.7,0.67,0.962,'2026-04-28 20:55:17'),(8394,3,358647.139,5.877,535.6,0.65,0.961,'2026-04-28 20:57:17'),(8395,3,358700.853,5.866,535.7,0.66,0.962,'2026-04-28 20:59:17'),(8396,3,358754.507,5.893,535.6,0.65,0.961,'2026-04-28 21:01:17'),(8397,3,358808.122,5.872,535.7,0.66,0.961,'2026-04-28 21:03:17'),(8398,3,358826.45,5.828,156.1,1.6,0.957,'2026-04-28 21:05:17'),(8399,3,358860.54,5.852,461.2,0.66,0.96,'2026-04-28 21:07:17'),(8400,3,358906.839,5.811,460.8,0.69,0.96,'2026-04-28 21:09:17'),(8401,3,358908.94,5.957,4.8,7.77,0.493,'2026-04-28 21:11:17'),(8402,3,358909.185,5.943,4.6,9.72,0.482,'2026-04-28 21:13:17'),(8403,3,358909.413,5.944,4.3,9.58,0.458,'2026-04-28 21:15:17'),(8404,3,358909.605,5.94,3.8,9.59,0.426,'2026-04-28 21:17:17'),(8405,3,358909.76,5.924,4,8.29,0.438,'2026-04-28 21:19:17'),(8406,3,358933.382,5.752,303.6,0.82,0.959,'2026-04-28 21:21:17'),(8407,3,358970.036,5.778,436.8,0.7,0.959,'2026-04-28 21:23:17'),(8408,3,359013.637,5.806,433.8,0.68,0.958,'2026-04-28 21:25:17'),(8409,3,359060.308,5.83,491.8,0.71,0.959,'2026-04-28 21:27:17'),(8410,3,359109.567,5.822,528.7,0.67,0.959,'2026-04-28 21:29:17'),(8411,3,359162.224,5.861,528.3,0.65,0.958,'2026-04-28 21:31:17'),(8412,3,359216.669,5.822,548.7,0.65,0.958,'2026-04-28 21:33:17'),(8413,3,359271.226,5.78,548.5,0.6,0.959,'2026-04-28 21:35:17'),(8414,3,359325.757,5.838,548.5,0.61,0.959,'2026-04-28 21:37:17'),(8415,3,359380.197,5.831,548.1,0.63,0.959,'2026-04-28 21:39:17'),(8416,3,359434.528,5.867,548,0.65,0.959,'2026-04-28 21:41:17'),(8417,3,359488.864,5.856,548,0.61,0.959,'2026-04-28 21:43:17'),(8418,3,359543.206,5.874,548.2,0.63,0.959,'2026-04-28 21:45:17'),(8419,3,359597.535,5.883,548.1,0.64,0.959,'2026-04-28 21:47:17'),(8420,3,359651.867,5.857,548,0.64,0.959,'2026-04-28 21:49:17'),(8421,3,359706.092,5.885,548.2,0.63,0.959,'2026-04-28 21:51:17'),(8422,3,359760.803,5.852,548.1,0.63,0.959,'2026-04-28 21:53:17'),(8423,3,359814.962,5.883,548.1,0.65,0.959,'2026-04-28 21:55:17'),(8424,3,359869.214,5.926,548,0.64,0.959,'2026-04-28 21:57:17'),(8425,3,359923.453,5.931,548,0.63,0.959,'2026-04-28 21:59:17'),(8426,3,359977.565,5.921,548.2,0.66,0.959,'2026-04-28 22:01:17'),(8427,3,360030.758,5.892,27.5,15.42,0.803,'2026-04-28 22:03:17'),(8428,3,360040.165,5.871,529.4,0.68,0.96,'2026-04-28 22:05:17'),(8429,3,360092.347,5.959,528.1,0.72,0.96,'2026-04-28 22:07:17'),(8430,3,360144.357,5.974,527.8,0.68,0.96,'2026-04-28 22:09:17'),(8431,3,360196.295,5.983,528.1,0.68,0.96,'2026-04-28 22:11:17'),(8432,3,360226.936,6.078,4.9,9.61,0.494,'2026-04-28 22:13:17'),(8433,3,360246.955,5.913,358.3,0.8,0.961,'2026-04-28 22:15:17'),(8434,3,360263.852,5.932,142.7,1.89,0.955,'2026-04-28 22:17:17'),(8435,3,360264.327,6.041,4.8,12.08,0.502,'2026-04-28 22:19:17'),(8436,3,360264.575,6.074,4.9,8.31,0.497,'2026-04-28 22:21:17'),(8437,3,360264.824,6.069,4.8,8.7,0.495,'2026-04-28 22:23:17'),(8438,3,360295.465,5.891,537.4,0.76,0.961,'2026-04-28 22:25:17'),(8439,3,360297.578,6.057,4.9,7.32,0.497,'2026-04-28 22:27:17'),(8440,3,360300.42,5.89,147.7,1.75,0.956,'2026-04-28 22:29:17'),(8441,3,360330.23,5.929,545.7,0.75,0.961,'2026-04-28 22:31:17'),(8442,3,360383.593,5.991,544.7,0.66,0.961,'2026-04-28 22:33:17'),(8443,3,360436.8,5.988,544.8,0.64,0.961,'2026-04-28 22:35:17'),(8444,3,360446.837,6.15,4.9,9.34,0.5,'2026-04-28 22:37:17'),(8445,3,360447.083,6.136,4.8,7.85,0.49,'2026-04-28 22:39:17'),(8446,3,360447.312,6.093,4.3,6.78,0.46,'2026-04-28 22:41:17'),(8447,3,360447.504,6.105,3.9,6.58,0.431,'2026-04-28 22:43:17'),(8448,3,360453.438,5.922,354.6,0.82,0.961,'2026-04-28 22:45:17'),(8449,3,360498.338,5.96,532.7,0.68,0.961,'2026-04-28 22:47:17'),(8450,3,360550.559,5.999,532,0.7,0.961,'2026-04-28 22:49:17'),(8451,3,360604.062,5.997,558,0.67,0.961,'2026-04-28 22:51:17'),(8452,3,360658.755,6,558,0.7,0.962,'2026-04-28 22:53:17'),(8453,3,360713.518,5.985,557.6,0.69,0.961,'2026-04-28 22:55:17'),(8454,3,360768.28,6.026,558.2,0.7,0.961,'2026-04-28 22:57:17'),(8455,3,360822.983,6.045,558,0.65,0.961,'2026-04-28 22:59:17'),(8456,3,360877.705,6.001,557.5,0.67,0.961,'2026-04-28 23:01:17'),(8457,3,360932.419,6.032,557.7,0.72,0.961,'2026-04-28 23:03:17'),(8458,3,360987.297,6.012,557.3,0.67,0.962,'2026-04-28 23:05:17'),(8459,3,361042.099,6.012,557.5,0.65,0.962,'2026-04-28 23:07:17'),(8460,3,361096.741,6.011,557.3,0.65,0.962,'2026-04-28 23:09:17'),(8461,3,361151.355,6.049,557.2,0.66,0.962,'2026-04-28 23:11:17'),(8462,3,361206.391,6.057,557.5,0.72,0.962,'2026-04-28 23:13:17'),(8463,3,361260.959,6.054,557.7,0.64,0.962,'2026-04-28 23:15:17'),(8464,3,361315.625,6.065,557.5,0.65,0.962,'2026-04-28 23:17:17'),(8465,3,361370.281,6.101,557.5,0.71,0.962,'2026-04-28 23:19:17'),(8466,3,361424.938,6.118,557.4,0.66,0.962,'2026-04-28 23:21:17'),(8467,3,361435.413,6.226,4.9,6.27,0.507,'2026-04-28 23:23:17'),(8468,3,361466.024,5.967,357.1,0.76,0.962,'2026-04-28 23:25:17'),(8469,3,361501.476,5.974,357.1,0.73,0.962,'2026-04-28 23:27:17'),(8470,3,361537.273,5.91,357.1,0.73,0.962,'2026-04-28 23:29:17'),(8471,3,361582.934,5.889,533,0.63,0.961,'2026-04-28 23:31:17'),(8472,3,361636.324,5.925,533.1,0.63,0.961,'2026-04-28 23:33:17'),(8473,3,361645.819,6.123,4.9,5.79,0.503,'2026-04-28 23:35:17'),(8474,3,361646.077,6.114,4.8,5.95,0.498,'2026-04-28 23:37:17'),(8475,3,361646.327,6.12,4.7,4.86,0.486,'2026-04-28 23:39:17'),(8476,3,361646.55,6.139,4.4,5.61,0.465,'2026-04-28 23:41:17'),(8477,3,361646.737,6.145,3.8,2.94,1.58,'2026-04-28 23:43:17'),(8478,3,361646.888,6.144,3.4,4.7,1.601,'2026-04-28 23:45:17'),(8479,3,361669.218,5.889,255.8,0.9,0.96,'2026-04-28 23:47:17'),(8480,3,361695.852,5.9,331.8,0.72,0.961,'2026-04-28 23:49:17'),(8481,3,361736.373,5.905,446.8,0.67,0.961,'2026-04-28 23:51:17'),(8482,3,361781.071,5.938,447.5,0.64,0.961,'2026-04-28 23:53:17'),(8483,3,361825.725,5.925,446.9,0.65,0.961,'2026-04-28 23:55:17'),(8484,3,361872.51,5.976,505.3,0.64,0.961,'2026-04-28 23:57:17'),(8485,3,361923.365,5.994,505.4,0.6,0.961,'2026-04-28 23:59:17'),(8486,3,361973.726,5.988,505.2,0.62,0.961,'2026-04-29 00:01:17'),(8487,3,362023.576,6.011,505,0.65,0.961,'2026-04-29 00:03:17'),(8488,3,362073.681,6.064,505.3,0.66,0.961,'2026-04-29 00:05:17'),(8489,3,362123.601,6.064,505.1,0.64,0.961,'2026-04-29 00:07:17'),(8490,3,362173.45,6.071,505.1,0.64,0.961,'2026-04-29 00:09:17'),(8491,3,362223.236,6.031,504.9,0.62,0.961,'2026-04-29 00:11:17'),(8492,3,362272.912,6.018,505.1,0.63,0.961,'2026-04-29 00:13:17'),(8493,3,362322.486,6.033,505.1,0.62,0.961,'2026-04-29 00:15:17'),(8494,3,362372.022,6.092,505.3,0.63,0.962,'2026-04-29 00:17:17'),(8495,3,362421.494,6.036,505.2,0.65,0.961,'2026-04-29 00:19:17'),(8496,3,362470.85,6.073,505.2,0.62,0.961,'2026-04-29 00:21:17'),(8497,3,362520.13,5.998,504.9,0.61,0.961,'2026-04-29 00:23:17'),(8498,3,362569.513,5.943,505,0.62,0.962,'2026-04-29 00:25:17'),(8499,3,362619.208,5.889,505,0.58,0.962,'2026-04-29 00:27:17'),(8500,3,362669.082,5.92,504.9,0.62,0.962,'2026-04-29 00:29:17'),(8501,3,362718.411,5.952,307.1,0.89,0.958,'2026-04-29 00:31:17'),(8502,3,362719.181,6.126,4.9,8.1,0.502,'2026-04-29 00:33:17'),(8503,3,362754.976,5.848,519.8,0.6,0.961,'2026-04-29 00:35:17'),(8504,3,362805.995,5.846,519.4,0.63,0.962,'2026-04-29 00:37:17'),(8505,3,362857.038,5.906,519.3,0.58,0.961,'2026-04-29 00:39:17'),(8506,3,362908.104,5.807,519.4,0.65,0.961,'2026-04-29 00:41:17'),(8507,3,362959.452,5.744,519.4,0.66,0.96,'2026-04-29 00:43:17'),(8508,3,363011.023,5.801,519.5,0.65,0.96,'2026-04-29 00:45:17'),(8509,3,363031.238,6.023,4.9,9.72,0.499,'2026-04-29 00:47:17'),(8510,3,363031.494,5.996,4.9,8.86,0.498,'2026-04-29 00:49:17'),(8511,3,363031.746,5.97,4.8,11.41,0.501,'2026-04-29 00:51:17'),(8512,3,363031.996,5.955,4.8,14.41,0.501,'2026-04-29 00:53:17'),(8513,3,363032.245,5.939,4.8,12.49,0.503,'2026-04-29 00:55:17'),(8514,3,363067.378,5.846,522.7,0.55,0.958,'2026-04-29 00:57:17'),(8515,3,363118.436,5.921,522.4,0.61,0.958,'2026-04-29 00:59:17'),(8516,3,363148.949,6.032,4.8,11.95,0.492,'2026-04-29 01:01:17'),(8517,3,363149.2,6.065,4.9,11.62,0.491,'2026-04-29 01:03:17'),(8518,3,363149.443,6.124,4.7,11.22,0.485,'2026-04-29 01:05:17'),(8519,3,363149.657,6.16,4.3,10.69,0.456,'2026-04-29 01:07:17'),(8520,3,363149.836,6.129,3.7,6.41,0.415,'2026-04-29 01:09:17'),(8521,3,363150.452,5.985,157,1.59,0.952,'2026-04-29 01:11:17'),(8522,3,363192.73,5.995,482.3,0.74,0.955,'2026-04-29 01:13:17'),(8523,3,363240.603,6.01,482.3,0.71,0.955,'2026-04-29 01:15:17'),(8524,3,363288.383,5.967,482.2,0.7,0.955,'2026-04-29 01:17:17'),(8525,3,363336.202,5.981,482.2,0.72,0.955,'2026-04-29 01:19:17'),(8526,3,363384.013,6.018,482.3,0.73,0.955,'2026-04-29 01:21:17'),(8527,3,363434.927,6.005,525.4,0.62,0.956,'2026-04-29 01:23:17'),(8528,3,363487.043,6.026,525.2,0.6,0.955,'2026-04-29 01:25:17'),(8529,3,363539.124,6.092,525.3,0.66,0.954,'2026-04-29 01:27:17'),(8530,3,363591.171,6.089,525.3,0.6,0.955,'2026-04-29 01:29:17'),(8531,3,363643.141,6.066,524.7,0.6,0.954,'2026-04-29 01:31:17'),(8532,3,363695.139,6.017,525.1,0.7,0.954,'2026-04-29 01:33:17'),(8533,3,363747.116,6.084,525.2,0.77,0.954,'2026-04-29 01:35:17'),(8534,3,363799.137,6.049,524.9,0.7,0.955,'2026-04-29 01:37:17'),(8535,3,363851.299,6.034,525,0.71,0.955,'2026-04-29 01:39:17'),(8536,3,363903.5,6.032,524.9,0.68,0.955,'2026-04-29 01:41:17'),(8537,3,363955.766,6.05,525,0.63,0.954,'2026-04-29 01:43:17'),(8538,3,364008.03,5.948,524.7,0.61,0.955,'2026-04-29 01:45:17'),(8539,3,364060.295,5.886,524.7,0.7,0.955,'2026-04-29 01:47:17'),(8540,3,364112.618,6.021,524.8,0.7,0.955,'2026-04-29 01:49:17'),(8541,3,364116.043,5.971,182.6,1.3,0.952,'2026-04-29 01:51:17'),(8542,3,364134.739,6.035,187.3,1.44,0.952,'2026-04-29 01:53:17'),(8543,3,364153.448,6.071,187.4,1.38,0.952,'2026-04-29 01:55:17'),(8544,3,364172.142,6.042,187.5,1.44,0.952,'2026-04-29 01:57:17'),(8545,3,364190.82,6.06,187.3,1.36,0.952,'2026-04-29 01:59:17'),(8546,3,364235.124,6.092,531,0.61,0.954,'2026-04-29 02:01:17'),(8547,3,364287.794,6.113,530.7,0.57,0.954,'2026-04-29 02:03:17'),(8548,3,364340.422,6.145,530.6,0.6,0.954,'2026-04-29 02:05:17'),(8549,3,364393.021,6.104,530.4,0.65,0.954,'2026-04-29 02:07:17'),(8550,3,364445.643,6.102,530.4,0.61,0.954,'2026-04-29 02:09:17'),(8551,3,364498.249,6.081,530.3,0.57,0.954,'2026-04-29 02:11:17'),(8552,3,364550.834,6.131,530.4,0.66,0.954,'2026-04-29 02:13:17'),(8553,3,364560.525,6.177,4.7,10.91,0.491,'2026-04-29 02:15:17'),(8554,3,364560.741,6.144,4.2,11.91,0.463,'2026-04-29 02:17:17'),(8555,3,364560.916,6.156,3.4,10.59,0.402,'2026-04-29 02:19:17'),(8556,3,364577.812,6.008,443.4,0.72,0.955,'2026-04-29 02:21:17'),(8557,3,364621.762,5.96,443.1,0.71,0.955,'2026-04-29 02:23:17'),(8558,3,364667.318,6.009,482.8,0.71,0.955,'2026-04-29 02:25:17'),(8559,3,364715.091,5.991,483,0.62,0.955,'2026-04-29 02:27:17'),(8560,3,364762.782,5.974,482.7,0.7,0.955,'2026-04-29 02:29:17'),(8561,3,364810.505,5.984,482.6,0.74,0.955,'2026-04-29 02:31:17'),(8562,3,364861.498,6.006,525.3,0.66,0.955,'2026-04-29 02:33:17'),(8563,3,364913.388,6.058,525.3,0.69,0.955,'2026-04-29 02:35:17'),(8564,3,364965.236,6.081,525,0.65,0.955,'2026-04-29 02:37:17'),(8565,3,365017.238,6.076,525.3,0.57,0.955,'2026-04-29 02:39:17'),(8566,3,365069.2,6.052,525.1,0.6,0.955,'2026-04-29 02:41:17'),(8567,3,365121.103,6.053,524.9,0.58,0.954,'2026-04-29 02:43:17'),(8568,3,365172.957,6.052,524.9,0.62,0.955,'2026-04-29 02:45:17'),(8569,3,365224.765,6.055,524.8,0.61,0.955,'2026-04-29 02:47:17'),(8570,3,365276.596,6.119,524.8,0.61,0.955,'2026-04-29 02:49:17'),(8571,3,365328.466,6.102,524.9,0.74,0.955,'2026-04-29 02:51:17'),(8572,3,365380.345,6.057,524.9,0.65,0.955,'2026-04-29 02:53:17'),(8573,3,365432.225,6.073,524.8,0.66,0.955,'2026-04-29 02:55:17'),(8574,3,365484.081,6.087,524.7,0.61,0.955,'2026-04-29 02:57:18'),(8575,3,365536.384,6.117,525,0.6,0.955,'2026-04-29 02:59:18'),(8576,3,365587.787,6.165,524.9,0.67,0.955,'2026-04-29 03:01:17'),(8577,3,365617.188,6.165,4.8,9.24,0.501,'2026-04-29 03:03:17'),(8578,3,365623.475,6.044,132.2,2.36,0.949,'2026-04-29 03:05:17'),(8579,3,365636.56,6.062,132.3,2.25,0.949,'2026-04-29 03:07:17'),(8580,3,365649.652,6.064,132.2,2.22,0.949,'2026-04-29 03:09:17'),(8581,3,365662.721,6.115,132.3,2.38,0.949,'2026-04-29 03:11:17'),(8582,3,365705.94,6.108,532,0.54,0.954,'2026-04-29 03:13:17'),(8583,3,365758.356,6.123,531.2,0.64,0.955,'2026-04-29 03:15:17'),(8584,3,365810.698,6.129,531.3,0.71,0.955,'2026-04-29 03:17:17'),(8585,3,365863.001,6.127,530.9,0.74,0.955,'2026-04-29 03:19:17'),(8586,3,365868.168,6.189,4.7,11.73,0.49,'2026-04-29 03:21:17'),(8587,3,365868.39,6.211,4.2,12.41,1.538,'2026-04-29 03:23:17'),(8588,3,365868.564,6.188,3.6,10.64,1.586,'2026-04-29 03:25:17'),(8589,3,365873.241,6.046,461.5,0.54,0.954,'2026-04-29 03:27:17'),(8590,3,365918.746,6.071,461.3,0.67,0.954,'2026-04-29 03:29:17'),(8591,3,365964.153,6.074,461.4,0.67,0.954,'2026-04-29 03:31:17'),(8592,3,366014.24,6.133,514.3,0.59,0.954,'2026-04-29 03:33:17'),(8593,3,366064.683,6.162,514.3,0.63,0.954,'2026-04-29 03:35:17'),(8594,3,366115.017,6.163,514.3,0.56,0.954,'2026-04-29 03:37:17'),(8595,3,366165.323,6.169,513.7,0.69,0.954,'2026-04-29 03:39:17'),(8596,3,366215.652,6.197,514.1,0.67,0.954,'2026-04-29 03:41:17'),(8597,3,366266.115,6.173,513.8,0.62,0.954,'2026-04-29 03:43:17'),(8598,3,366316.564,6.164,513.9,0.61,0.954,'2026-04-29 03:45:17'),(8599,3,366367.015,6.115,514,0.63,0.954,'2026-04-29 03:47:17'),(8600,3,366417.43,6.156,513.9,0.61,0.954,'2026-04-29 03:49:17'),(8601,3,366467.728,6.142,513.9,0.6,0.955,'2026-04-29 03:51:17'),(8602,3,366517.968,6.226,513.8,0.58,0.955,'2026-04-29 03:53:17'),(8603,3,366568.231,6.168,513.4,0.6,0.955,'2026-04-29 03:55:17'),(8604,3,366618.487,6.153,514,0.58,0.955,'2026-04-29 03:57:17'),(8605,3,366668.754,6.179,513.9,0.61,0.955,'2026-04-29 03:59:17'),(8606,3,366719.042,6.198,513.9,0.6,0.956,'2026-04-29 04:01:17'),(8607,3,366769.379,6.168,513.6,0.61,0.956,'2026-04-29 04:03:17'),(8608,3,366819.715,6.219,513.9,0.64,0.956,'2026-04-29 04:05:19'),(8609,3,366870.064,6.166,513.7,0.69,0.956,'2026-04-29 04:07:17'),(8610,3,366920.414,6.164,513.8,0.67,0.956,'2026-04-29 04:09:17'),(8611,3,366970.752,6.123,513.8,0.67,0.956,'2026-04-29 04:11:17'),(8612,3,367021.043,6.173,513.7,0.69,0.957,'2026-04-29 04:13:17'),(8613,3,367071.275,6.169,513.7,0.72,0.957,'2026-04-29 04:15:17'),(8614,3,367103.159,6.247,4.9,8.39,0.502,'2026-04-29 04:17:17'),(8615,3,367106.499,6.114,145.4,1.84,0.952,'2026-04-29 04:19:17'),(8616,3,367120.828,6.194,145.6,1.81,0.952,'2026-04-29 04:21:17'),(8617,3,367135.169,6.16,145.7,1.76,0.952,'2026-04-29 04:23:17'),(8618,3,367149.472,6.148,145.6,1.78,0.952,'2026-04-29 04:25:17'),(8619,3,367170.358,6.185,493.2,0.59,0.957,'2026-04-29 04:27:17'),(8620,3,367209.472,6.28,4.9,8.38,0.5,'2026-04-29 04:29:17'),(8621,3,367209.723,6.253,4.8,8.54,0.499,'2026-04-29 04:31:17'),(8622,3,367209.946,6.274,4.4,7.32,0.467,'2026-04-29 04:33:17'),(8623,3,367210.118,6.251,3.6,7.2,1.585,'2026-04-29 04:35:17'),(8624,3,367247.083,6.12,483,0.62,0.957,'2026-04-29 04:37:17'),(8625,3,367294.663,6.042,482.9,0.71,0.957,'2026-04-29 04:39:17'),(8626,3,367342.18,6.057,481.8,0.71,0.958,'2026-04-29 04:41:17'),(8627,3,367389.64,6.087,482.6,0.69,0.958,'2026-04-29 04:43:17'),(8628,3,367438.232,6.09,524.6,0.78,0.958,'2026-04-29 04:45:17'),(8629,3,367489.751,6.145,524.5,0.68,0.958,'2026-04-29 04:47:17'),(8630,3,367540.997,6.157,524.9,0.73,0.958,'2026-04-29 04:49:17'),(8631,3,367592.147,6.204,524.1,0.71,0.958,'2026-04-29 04:51:17'),(8632,3,367643.398,6.185,523.8,0.65,0.958,'2026-04-29 04:53:17'),(8633,3,367694.856,6.205,524.3,0.59,0.958,'2026-04-29 04:55:17'),(8634,3,367746.476,6.209,524.3,0.61,0.958,'2026-04-29 04:57:17'),(8635,3,367798.249,6.172,524.2,0.57,0.957,'2026-04-29 04:59:17'),(8636,3,367850.284,6.199,524.2,0.61,0.958,'2026-04-29 05:01:17'),(8637,3,367902.411,6.184,524.2,0.61,0.958,'2026-04-29 05:03:17'),(8638,3,367954.592,6.209,524.2,0.59,0.957,'2026-04-29 05:05:17'),(8639,3,368006.765,6.21,524.2,0.62,0.957,'2026-04-29 05:07:17'),(8640,3,368058.945,6.199,524.4,0.61,0.958,'2026-04-29 05:09:17'),(8641,3,368111.076,6.215,524.1,0.56,0.958,'2026-04-29 05:11:17'),(8642,3,368140.893,6.31,5,7.95,0.5,'2026-04-29 05:13:17'),(8643,3,368154.194,6.252,533.3,0.61,0.957,'2026-04-29 05:15:17'),(8644,3,368206.923,6.263,531.9,0.62,0.958,'2026-04-29 05:17:17'),(8645,3,368259.135,6.226,531.9,0.65,0.957,'2026-04-29 05:19:17'),(8646,3,368311.738,6.218,531.8,0.6,0.958,'2026-04-29 05:21:17'),(8647,3,368364.322,6.19,531.5,0.65,0.958,'2026-04-29 05:23:17'),(8648,3,368416.875,6.236,531.5,0.62,0.958,'2026-04-29 05:25:17'),(8649,3,368425.362,6.259,4.9,7.68,0.503,'2026-04-29 05:27:17'),(8650,3,368438.844,6.156,148.6,1.74,0.952,'2026-04-29 05:29:17'),(8651,3,368453.51,6.18,148.8,1.79,0.952,'2026-04-29 05:31:17'),(8652,3,368468.176,6.164,148.7,1.73,0.952,'2026-04-29 05:33:17'),(8653,3,368471.301,6.292,5,7.72,0.504,'2026-04-29 05:35:17'),(8654,3,368471.56,6.328,5,7.2,0.504,'2026-04-29 05:37:17'),(8655,3,368511.655,6.278,522,0.61,0.957,'2026-04-29 05:39:17'),(8656,3,368562.743,6.261,521.5,0.6,0.957,'2026-04-29 05:41:17'),(8657,3,368613.886,6.292,521.3,0.63,0.957,'2026-04-29 05:43:17'),(8658,3,368664.944,6.312,521.3,0.63,0.957,'2026-04-29 05:45:17'),(8659,3,368670.018,6.351,5,6.63,0.504,'2026-04-29 05:47:17'),(8660,3,368670.266,6.362,4.7,7.29,0.488,'2026-04-29 05:49:17'),(8661,3,368670.475,6.354,4.2,7.75,0.453,'2026-04-29 05:51:17'),(8662,3,368670.637,6.409,4.2,7.73,0.448,'2026-04-29 05:53:17'),(8663,3,368709.857,6.328,482.2,0.67,0.958,'2026-04-29 05:55:17'),(8664,3,368759.386,6.293,515.7,0.64,0.958,'2026-04-29 05:57:17'),(8665,3,368810.444,6.252,527.3,0.65,0.958,'2026-04-29 05:59:17'),(8666,3,368861.997,6.262,527.1,0.68,0.958,'2026-04-29 06:01:17'),(8667,3,368913.397,6.317,527.1,0.68,0.958,'2026-04-29 06:03:17'),(8668,3,368964.656,6.294,526.9,0.77,0.959,'2026-04-29 06:05:17'),(8669,3,369016.45,6.272,526.9,0.72,0.959,'2026-04-29 06:07:17'),(8670,3,369068.129,6.323,526.9,0.69,0.959,'2026-04-29 06:09:17'),(8671,3,369119.628,6.32,526.6,0.76,0.959,'2026-04-29 06:11:17'),(8672,3,369170.987,6.345,527.3,0.68,0.959,'2026-04-29 06:13:17'),(8673,3,369222.331,6.341,528,0.69,0.959,'2026-04-29 06:15:17'),(8674,3,369273.595,6.312,524,0.68,0.959,'2026-04-29 06:17:17'),(8675,3,369324.929,6.279,526.9,0.71,0.959,'2026-04-29 06:19:17');
/*!40000 ALTER TABLE `power_readings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('47Q8QzLTPmVCrT6SBqewPGw1vMZJM4SvyqPul9kE',NULL,'10.88.8.53','Mozilla/5.0 (Windows NT 6.1; rv:109.0) Gecko/20100101 Firefox/115.0','eyJfdG9rZW4iOiJoOEZaTXpkOGhlblBmWUl5WGxzaVpQRjByWEZRZlBTY3JTZjJjR1BkIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cLzEwLjg4LjguOTdcL2VuZXJneS10cmFja2VyXC9wdWJsaWNcL2luZGV4LnBocFwvbG9naW4iLCJyb3V0ZSI6ImxvZ2luIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1775122151),('9Ie2CRUeNuIHbSeIUbHjgPvMmLyHLjVMfEWa5TNh',3,'10.88.8.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','eyJfdG9rZW4iOiJTR241eWYyVHRBcjlNNGt3ZUNEMWtadU9rTjlYYThYN25vU2k4MkxJIiwidXJsIjpbXSwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cLzEwLjg4LjguOTdcL2VuZXJneS10cmFja2VyXC9wdWJsaWNcL2luZGV4LnBocFwvcmVwb3J0cz9lbmRfZGF0ZT0yMDI2LTA0LTAyJm1hY2hpbmVfaWQ9MSZzdGFydF9kYXRlPTIwMjYtMDMtMDMiLCJyb3V0ZSI6InJlcG9ydHMifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119LCJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI6M30=',1775127136),('bvYMc97D6Z4Z028YoGjVrAAa6zisL5TKBBjpT0G4',NULL,'10.88.8.53','Mozilla/5.0 (Windows NT 6.1; rv:109.0) Gecko/20100101 Firefox/115.0','eyJfdG9rZW4iOiI0OWFONElFd2NOeFZtSXFva2RzWDdmcjVCTFRUcVJWV3RJT3ZqUUVNIiwidXJsIjp7ImludGVuZGVkIjoiaHR0cDpcL1wvMTAuODguOC45N1wvZW5lcmd5LXRyYWNrZXJcL3B1YmxpY1wvaW5kZXgucGhwIn0sIl9wcmV2aW91cyI6eyJ1cmwiOiJodHRwOlwvXC8xMC44OC44Ljk3XC9lbmVyZ3ktdHJhY2tlclwvcHVibGljXC9pbmRleC5waHAiLCJyb3V0ZSI6ImRhc2hib2FyZCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1775122151),('eWGgsn5rp2KW1Snb9B9AIaZ00oOalcXRGrU4Wg8s',NULL,'10.88.8.130','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0','eyJfdG9rZW4iOiJ0bERlSEFGOHJQRXkwVGJmVUZlZWtCRTRZMERnU3Z3eUFmWXpuRUlNIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cLzEwLjg4LjguOTdcL2VuZXJneS10cmFja2VyXC9wdWJsaWNcL2luZGV4LnBocFwvbG9naW4iLCJyb3V0ZSI6ImxvZ2luIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1775120076),('LjmwHK5ZjYa7jp5SQNoNx4fuAAQrgOFHSDJIHY7H',3,'10.88.8.63','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','eyJfdG9rZW4iOiJGMHNLRWV2dkY4OWt5VVRydzRQT2ZacVo0NXVYN0pFbnp5ZFVlejJaIiwidXJsIjpbXSwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cLzEwLjg4LjguOTdcL2VuZXJneS10cmFja2VyXC9wdWJsaWNcL2luZGV4LnBocCIsInJvdXRlIjoiZGFzaGJvYXJkIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfSwibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiOjN9',1775121652),('LR8FlzdbxgKawLSyxsGch3p7IipWVe1ZlVQtlVEz',NULL,'10.88.8.53','Mozilla/5.0 (Windows NT 6.1; rv:109.0) Gecko/20100101 Firefox/115.0','eyJfdG9rZW4iOiJoUUNoeVB3aGN4TnhnbXJwaTVHZFlHRG9vNXRFMEh0dzM1MVFEZzJkIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119LCJfcHJldmlvdXMiOnsidXJsIjoiaHR0cDpcL1wvMTAuODguOC45N1wvZW5lcmd5LXRyYWNrZXJcL3B1YmxpY1wvaW5kZXgucGhwXC9sb2dpbiIsInJvdXRlIjoibG9naW4ifX0=',1775123069);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Direktur','direktur@peroniks.com',NULL,'$2y$12$tk2vDTOFch9YelspryGuJeYISbhX9HSE745wfrfaFw/ZrfNivJl7W',NULL,'2026-04-02 00:45:11','2026-04-02 00:45:11'),(2,'Finance','finance@peroniks.com',NULL,'$2y$12$r5QxiMDFtGIMU38YkmQt9uADCPjiSqjMZ9gNtBdUNRO5WnlX/BuiK',NULL,'2026-04-02 00:45:11','2026-04-02 00:45:11'),(3,'Management Rep','mr@peroniks.com',NULL,'$2y$12$SVbfa4tcYl1hIWcqVJtcVecdIlspRZDcfpcbgYdb7IMcn7rDFkg7m',NULL,'2026-04-02 00:45:11','2026-04-03 09:43:52'),(4,'Manager HR','managerhr@peroniks.com',NULL,'$2y$12$2Yu37pCvopGIFtFMaQpfyu8H4Uh1nTz0Oiuuuriahtn3uMq0OQlMK',NULL,'2026-04-02 00:45:11','2026-04-02 00:45:11'),(5,'Kabag Maintenance','kabagmaintenance@peroniks.com',NULL,'$2y$12$iVlFmPlJFGCS6O9OX.0kdOGv1cwamN5EXHKZLA6a5TVPjke7BNMIm','jRs8uLfGHfzxaId5AJ4ngNfgNCE43jBYpIlCzf6PI6VaN2yQHQV3JWfEgxfb','2026-04-02 00:45:11','2026-04-02 00:45:11'),(6,'Marketing Export','marketingexport@peroniks.com',NULL,'$2y$12$ZH/KDOtxrOIuTpSCjBVLrupcXD6Z20E2M3iBivB91cJjNFni3y0qS',NULL,'2026-04-02 00:45:11','2026-04-02 00:45:11'),(7,'Pajak','pajak@peroniks.com',NULL,'$2y$12$DlcQFS3DSjzYJljQWbizF.kA1MfHZsW5CGVULW4xB9k5R7rd/gzty',NULL,'2026-04-02 00:45:11','2026-04-02 00:45:11');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'energy_tracker'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-29 13:19:28
